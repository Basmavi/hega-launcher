package com.ismail.launcher

import android.net.Uri

data class VideoInfo(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val mimeType: String,
    val dateMillis: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val relativePath: String
)
