package com.ismail.launcher

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.FrameLayout

/**
 * dragEnabled = true yapıldığında, bir sonraki dokunuş-sürükleme hareketiyle
 * görünümü taşır ve bırakıldığında onDragEnd(translationX, translationY) çağrılır.
 */
class DragLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    var dragEnabled: Boolean = false
    var onDragEnd: ((Float, Float) -> Unit)? = null

    private var startRawX = 0f
    private var startRawY = 0f
    private var baseTx = 0f
    private var baseTy = 0f

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        return dragEnabled || super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!dragEnabled) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startRawX = event.rawX
                startRawY = event.rawY
                baseTx = translationX
                baseTy = translationY
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                translationX = baseTx + (event.rawX - startRawX)
                translationY = baseTy + (event.rawY - startRawY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragEnabled = false
                onDragEnd?.invoke(translationX, translationY)
                onDragEnd = null
            }
        }
        return true
    }
}
