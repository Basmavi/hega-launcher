package com.ismail.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class PhotoAdapter(
    private var items: List<PhotoInfo>,
    private val onTap: (Int) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.thumb)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val photo = items[position]
        holder.image.setImageDrawable(null)
        val tag = photo.id
        holder.itemView.tag = tag
        val context = holder.itemView.context.applicationContext
        pool.execute {
            val bmp = PhotoScanner.loadThumb(context, photo, 256)
            holder.itemView.post {
                if (holder.itemView.tag == tag && bmp != null) holder.image.setImageBitmap(bmp)
            }
        }
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onTap(pos)
        }
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<PhotoInfo>) {
        items = newItems
        notifyDataSetChanged()
    }

    companion object {
        private val pool = Executors.newFixedThreadPool(3)
    }
}
