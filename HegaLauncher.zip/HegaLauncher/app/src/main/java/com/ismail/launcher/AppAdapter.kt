package com.ismail.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private var items: List<GridItem>,
    private val scope: String,
    private val onAppTap: (AppInfo) -> Unit,
    private val onAppLongPress: (AppInfo) -> Unit,
    private val onFolderTap: (GridItem.FolderItem) -> Unit,
    private val onFolderLongPress: (GridItem.FolderItem) -> Unit = {}
) : RecyclerView.Adapter<AppAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val context = holder.itemView.context
        val density = context.resources.displayMetrics.density
        val iconPx = (LauncherPrefs.getIconSizeDp(context, scope) * density).toInt()
        val shape = LauncherPrefs.getIconShape(context, scope)

        val iconParams = holder.icon.layoutParams
        iconParams.width = iconPx
        iconParams.height = iconPx
        holder.icon.layoutParams = iconParams
        holder.icon.scaleType = ImageView.ScaleType.FIT_CENTER
        holder.label.textSize = LauncherPrefs.getLabelSizeSp(context, scope).toFloat()
        holder.label.setTextColor(LauncherPrefs.getLabelColor(context, scope))
        holder.label.visibility = View.VISIBLE

        when (val item = items[position]) {
            is GridItem.AppItem -> {
                holder.icon.setImageDrawable(IconShaper.apply(context, item.app.icon, shape, iconPx))
                holder.label.text = item.app.label
                holder.itemView.setOnClickListener { onAppTap(item.app) }
                holder.itemView.setOnLongClickListener { onAppLongPress(item.app); true }
            }
            is GridItem.FolderItem -> {
                val preview = FolderIcon.build(context, item.icons.map { it.icon })
                holder.icon.setImageDrawable(IconShaper.apply(context, preview, shape, iconPx))
                holder.label.text = item.folder.name
                holder.itemView.setOnClickListener { onFolderTap(item) }
                holder.itemView.setOnLongClickListener { onFolderLongPress(item); true }
            }
        }
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<GridItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
