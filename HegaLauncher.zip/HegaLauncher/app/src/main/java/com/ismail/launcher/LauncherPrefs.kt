package com.ismail.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object LauncherPrefs {
    private const val NAME = "hega_launcher_prefs"
    private const val KEY_SHAPE = "icon_shape"
    private const val KEY_FOLDERS = "folders"
    private const val KEY_WIDGET_ID = "widget_id"
    private const val KEY_WIDGET_PROVIDER = "widget_provider"
    private const val KEY_DOCK = "dock"
    private const val KEY_ICON_SIZE = "icon_size_dp"
    private const val KEY_LABEL_SIZE = "label_size_sp"
    private const val KEY_LABEL_COLOR = "label_color"
    private const val KEY_COLUMNS = "columns"
    private const val KEY_ROWS = "rows"

    private fun prefs(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // ---------- İkon şekli ----------
    fun getIconShape(context: Context): String = prefs(context).getString(KEY_SHAPE, "square") ?: "square"
    fun setIconShape(context: Context, shape: String) { prefs(context).edit().putString(KEY_SHAPE, shape).apply() }

    // ---------- Görünüm ayarları ----------
    fun getIconSizeDp(context: Context): Int = prefs(context).getInt(KEY_ICON_SIZE, 56)
    fun setIconSizeDp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_ICON_SIZE, v).apply() }

    fun getLabelSizeSp(context: Context): Int = prefs(context).getInt(KEY_LABEL_SIZE, 12)
    fun setLabelSizeSp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_LABEL_SIZE, v).apply() }

    fun getLabelColor(context: Context): Int = prefs(context).getInt(KEY_LABEL_COLOR, 0xFFFFFFFF.toInt())
    fun setLabelColor(context: Context, v: Int) { prefs(context).edit().putInt(KEY_LABEL_COLOR, v).apply() }

    fun getColumns(context: Context): Int = prefs(context).getInt(KEY_COLUMNS, 4)
    fun setColumns(context: Context, v: Int) { prefs(context).edit().putInt(KEY_COLUMNS, v).apply() }

    fun getRows(context: Context): Int = prefs(context).getInt(KEY_ROWS, 5)
    fun setRows(context: Context, v: Int) { prefs(context).edit().putInt(KEY_ROWS, v).apply() }

    // ---------- Klasörler ----------
    fun getFolders(context: Context): MutableList<FolderInfo> {
        val raw = prefs(context).getString(KEY_FOLDERS, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val out = mutableListOf<FolderInfo>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val apps = mutableListOf<AppRef>()
            val appsArr = o.getJSONArray("apps")
            for (j in 0 until appsArr.length()) {
                val a = appsArr.getJSONObject(j)
                apps.add(AppRef(a.getString("pkg"), a.getString("cls")))
            }
            out.add(FolderInfo(o.getString("name"), apps))
        }
        return out
    }

    fun saveFolders(context: Context, folders: List<FolderInfo>) {
        val arr = JSONArray()
        folders.forEach { f ->
            val o = JSONObject()
            o.put("name", f.name)
            val appsArr = JSONArray()
            f.apps.forEach { a ->
                val ao = JSONObject()
                ao.put("pkg", a.packageName)
                ao.put("cls", a.activityName)
                appsArr.put(ao)
            }
            o.put("apps", appsArr)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_FOLDERS, arr.toString()).apply()
    }

    // ---------- Dock ----------
    fun getDock(context: Context): MutableList<AppRef> {
        val raw = prefs(context).getString(KEY_DOCK, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val out = mutableListOf<AppRef>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(AppRef(o.getString("pkg"), o.getString("cls")))
        }
        return out
    }

    fun saveDock(context: Context, dock: List<AppRef>) {
        val arr = JSONArray()
        dock.forEach { a ->
            val o = JSONObject()
            o.put("pkg", a.packageName)
            o.put("cls", a.activityName)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_DOCK, arr.toString()).apply()
    }

    // ---------- Widget ----------
    fun getWidget(context: Context): Pair<Int, String>? {
        val id = prefs(context).getInt(KEY_WIDGET_ID, -1)
        val provider = prefs(context).getString(KEY_WIDGET_PROVIDER, null)
        return if (id != -1 && provider != null) id to provider else null
    }

    fun saveWidget(context: Context, id: Int, provider: String) {
        prefs(context).edit().putInt(KEY_WIDGET_ID, id).putString(KEY_WIDGET_PROVIDER, provider).apply()
    }

    fun clearWidget(context: Context) {
        prefs(context).edit().remove(KEY_WIDGET_ID).remove(KEY_WIDGET_PROVIDER).apply()
    }
}
