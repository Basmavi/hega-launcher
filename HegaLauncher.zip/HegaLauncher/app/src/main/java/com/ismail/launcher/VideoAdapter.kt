package com.ismail.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class VideoAdapter(
    private var items: List<VideoInfo>,
    private val onTap: (Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val thumb: ImageView = view.findViewById(R.id.vThumb)
        val title: TextView = view.findViewById(R.id.vTitle)
        val sub: TextView = view.findViewById(R.id.vSub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val video = items[position]
        holder.title.text = video.displayName
        holder.sub.text = "${VideoScanner.formatDuration(video.durationMs)}  •  ${VideoScanner.formatSize(video.sizeBytes)}"
        holder.thumb.setImageDrawable(null)
        val tag = video.id
        holder.itemView.tag = tag
        val context = holder.itemView.context.applicationContext
        pool.execute {
            val bmp = VideoScanner.loadThumb(context, video, 320, 200)
            holder.itemView.post {
                if (holder.itemView.tag == tag && bmp != null) holder.thumb.setImageBitmap(bmp)
            }
        }
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onTap(pos)
        }
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<VideoInfo>) {
        items = newItems
        notifyDataSetChanged()
    }

    companion object {
        private val pool = Executors.newFixedThreadPool(3)
    }
}
