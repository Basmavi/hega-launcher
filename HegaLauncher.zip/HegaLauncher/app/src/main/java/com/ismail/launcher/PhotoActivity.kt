package com.ismail.launcher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class PhotoActivity : AppCompatActivity() {

    private class MenuEntry(val label: String, val action: () -> Unit)

    private lateinit var libraryScreen: View
    private lateinit var viewScreen: View
    private lateinit var editScreen: View
    private lateinit var scanBtn: Button
    private lateinit var permissionNotice: TextView
    private lateinit var photoAdapter: PhotoAdapter

    private lateinit var viewImage: ImageView
    private lateinit var viewDate: TextView
    private lateinit var viewTime: TextView

    private lateinit var editView: PhotoEditView
    private lateinit var cropControls: View
    private lateinit var drawControls: View
    private lateinit var colorRow: LinearLayout
    private lateinit var sizeLabel: TextView
    private lateinit var sizeSeek: SeekBar
    private lateinit var alphaLabel: TextView
    private lateinit var alphaSeek: SeekBar
    private lateinit var toolCrop: TextView
    private lateinit var toolPen: TextView
    private lateinit var toolEraser: TextView

    private var photos: List<PhotoInfo> = emptyList()
    private var currentIndex = -1
    private val currentPhoto: PhotoInfo? get() = photos.getOrNull(currentIndex)

    private val penColors = listOf(
        Color.RED, 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(), 0xFF2196F3.toInt(),
        Color.WHITE, Color.BLACK, 0xFFE91E63.toInt()
    )
    private var selectedColor = Color.RED
    private var penSizeDp = 6
    private var penAlpha = 100
    private var eraserSizeDp = 20
    private var eraserAlpha = 100

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionNotice.visibility = if (granted) View.GONE else View.VISIBLE
        if (granted) scan(null)
        else Toast.makeText(this, "İzin verilmeden fotoğraflar taranamaz", Toast.LENGTH_SHORT).show()
    }

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
            showLibrary()
            scan(null)
        } else {
            Toast.makeText(this, "Silme iptal edildi", Toast.LENGTH_SHORT).show()
        }
    }

    private val writeLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == RESULT_OK) performSave()
        else Toast.makeText(this, "Kaydetme izni verilmedi", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo)

        libraryScreen = findViewById(R.id.libraryScreen)
        viewScreen = findViewById(R.id.viewScreen)
        editScreen = findViewById(R.id.editScreen)
        scanBtn = findViewById(R.id.photoScanBtn)
        permissionNotice = findViewById(R.id.photoPermissionNotice)

        val list = findViewById<RecyclerView>(R.id.photoList)
        list.layoutManager = GridLayoutManager(this, 3)
        photoAdapter = PhotoAdapter(emptyList()) { position -> openViewer(position) }
        list.adapter = photoAdapter

        findViewById<TextView>(R.id.photoMenuBtn).setOnClickListener { showTopMenu() }
        scanBtn.setOnClickListener { ensurePermissionThenScan() }

        setupViewer()
        setupEditor()

        if (hasPermission()) scan(null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            editScreen.visibility == View.VISIBLE -> {
                editScreen.visibility = View.GONE
                viewScreen.visibility = View.VISIBLE
            }
            viewScreen.visibility == View.VISIBLE -> showLibrary()
            else -> super.onBackPressed()
        }
    }

    // ---------- İzin / tarama ----------

    private fun requiredPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, requiredPermission()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissionThenScan() {
        if (hasPermission()) scan(null) else permLauncher.launch(requiredPermission())
    }

    private fun scan(onDone: (() -> Unit)?) {
        scanBtn.isEnabled = false
        scanBtn.text = "Taranıyor…"
        Thread {
            val list = PhotoScanner.scan(this)
            runOnUiThread {
                scanBtn.isEnabled = true
                scanBtn.text = "Tara"
                val keepId = currentPhoto?.id
                photos = list
                currentIndex = if (keepId != null) list.indexOfFirst { it.id == keepId } else -1
                photoAdapter.update(list)
                if (list.isEmpty()) Toast.makeText(this, "Fotoğraf bulunamadı", Toast.LENGTH_SHORT).show()
                onDone?.invoke()
            }
        }.start()
    }

    private fun showLibrary() {
        viewScreen.visibility = View.GONE
        editScreen.visibility = View.GONE
        libraryScreen.visibility = View.VISIBLE
    }

    // ---------- Üst menü ----------

    private fun showMenu(entries: List<MenuEntry>) {
        AlertDialog.Builder(this)
            .setItems(entries.map { it.label }.toTypedArray()) { _, which -> entries[which].action() }
            .show()
    }

    private fun showTopMenu() {
        showMenu(listOf(MenuEntry("Ana ekrana ekle") { addSelfToHome() }))
    }

    private fun addSelfToHome() {
        val items = LauncherPrefs.getHomeItems(this)
        val already = items.any {
            it is HomeEntry.AppEntry && it.ref.packageName == packageName && it.ref.activityName == PhotoActivity::class.java.name
        }
        if (already) {
            Toast.makeText(this, "Hega Photos zaten ana ekranda", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeEntry.AppEntry(AppRef(packageName, PhotoActivity::class.java.name)))
        LauncherPrefs.saveHomeItems(this, items)
        Toast.makeText(this, "Hega Photos ana ekrana eklendi", Toast.LENGTH_SHORT).show()
    }

    // ---------- Görüntüleyici ----------

    private fun setupViewer() {
        viewImage = findViewById(R.id.viewImage)
        viewDate = findViewById(R.id.viewDate)
        viewTime = findViewById(R.id.viewTime)

        findViewById<View>(R.id.viewBack).setOnClickListener { showLibrary() }
        findViewById<View>(R.id.actShare).setOnClickListener { sharePhoto() }
        findViewById<View>(R.id.actEdit).setOnClickListener { openEditor() }
        findViewById<View>(R.id.actDelete).setOnClickListener { confirmDelete() }
        findViewById<View>(R.id.actInfo).setOnClickListener { showInfo() }

        // Sağa/sola kaydırarak önceki/sonraki fotoğraf
        var downX = 0f
        viewImage.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> downX = ev.x
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    if (abs(dx) > 150f) showRelative(if (dx < 0) 1 else -1)
                }
            }
            true
        }
    }

    private fun openViewer(index: Int) {
        if (index < 0 || index >= photos.size) return
        currentIndex = index
        libraryScreen.visibility = View.GONE
        editScreen.visibility = View.GONE
        viewScreen.visibility = View.VISIBLE
        loadViewer()
    }

    private fun showRelative(delta: Int) {
        val next = currentIndex + delta
        if (next < 0 || next >= photos.size) return
        currentIndex = next
        loadViewer()
    }

    private fun loadViewer() {
        val photo = currentPhoto ?: return
        val date = Date(photo.dateMillis)
        viewDate.text = SimpleDateFormat("d MMMM, yyyy", Locale("tr")).format(date)
        viewTime.text = SimpleDateFormat("HH:mm", Locale("tr")).format(date)
        viewImage.setImageDrawable(null)
        Thread {
            val bmp = PhotoScanner.loadBitmap(this, photo.uri, 2048)
            runOnUiThread {
                if (currentPhoto?.id == photo.id && bmp != null) viewImage.setImageBitmap(bmp)
            }
        }.start()
    }

    private fun sharePhoto() {
        val photo = currentPhoto ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = photo.mimeType
            putExtra(Intent.EXTRA_STREAM, photo.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "Paylaş"))
        } catch (e: Exception) {
            Toast.makeText(this, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showInfo() {
        val p = currentPhoto ?: return
        val date = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("tr")).format(Date(p.dateMillis))
        val sizeText = if (p.sizeBytes >= 1024 * 1024) {
            "%.1f MB".format(p.sizeBytes / 1024f / 1024f)
        } else {
            "${p.sizeBytes / 1024} KB"
        }
        val lines = mutableListOf(
            "Ad: ${p.displayName}",
            "Çözünürlük: ${p.width} × ${p.height}",
            "Dosya boyutu: $sizeText",
            "Tarih: $date",
            "Tür: ${p.mimeType}"
        )
        if (p.relativePath.isNotEmpty()) lines.add("Konum: ${p.relativePath}")
        AlertDialog.Builder(this)
            .setTitle("Hakkında")
            .setMessage(lines.joinToString("\n"))
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun confirmDelete() {
        val p = currentPhoto ?: return
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage("${p.displayName} silinsin mi?")
            .setPositiveButton("Sil") { _, _ -> deleteCurrentPhoto() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun deleteCurrentPhoto() {
        val p = currentPhoto ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(p.uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(this, "Silinemedi", Toast.LENGTH_SHORT).show()
            }
        } else {
            try {
                contentResolver.delete(p.uri, null, null)
                Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                showLibrary()
                scan(null)
            } catch (e: Exception) {
                Toast.makeText(this, "Silinemedi (izin gerekebilir)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Düzenleyici ----------

    private fun setupEditor() {
        editView = findViewById(R.id.editView)
        cropControls = findViewById(R.id.cropControls)
        drawControls = findViewById(R.id.drawControls)
        colorRow = findViewById(R.id.colorRow)
        sizeLabel = findViewById(R.id.sizeLabel)
        sizeSeek = findViewById(R.id.sizeSeek)
        alphaLabel = findViewById(R.id.alphaLabel)
        alphaSeek = findViewById(R.id.alphaSeek)
        toolCrop = findViewById(R.id.toolCrop)
        toolPen = findViewById(R.id.toolPen)
        toolEraser = findViewById(R.id.toolEraser)

        sizeSeek.max = 78      // 2..80 dp
        alphaSeek.max = 95     // %5..%100

        sizeSeek.setOnSeekBarChangeListener(seekListener { p ->
            val dp = p + 2
            if (editView.mode == PhotoEditView.Mode.ERASE) eraserSizeDp = dp else penSizeDp = dp
            sizeLabel.text = "Boyut: $dp"
            applyBrush()
        })
        alphaSeek.setOnSeekBarChangeListener(seekListener { p ->
            val a = p + 5
            if (editView.mode == PhotoEditView.Mode.ERASE) eraserAlpha = a else penAlpha = a
            alphaLabel.text = "Şeffaflık (opaklık): %$a"
            applyBrush()
        })

        findViewById<View>(R.id.editCancel).setOnClickListener {
            editScreen.visibility = View.GONE
            viewScreen.visibility = View.VISIBLE
        }
        findViewById<View>(R.id.editSave).setOnClickListener { saveEdit() }
        findViewById<View>(R.id.applyCropBtn).setOnClickListener {
            editView.commitCrop()
            selectTool(PhotoEditView.Mode.DRAW)
        }
        findViewById<View>(R.id.clearBtn).setOnClickListener { editView.clearDrawing() }
        toolCrop.setOnClickListener { selectTool(PhotoEditView.Mode.CROP) }
        toolPen.setOnClickListener { selectTool(PhotoEditView.Mode.DRAW) }
        toolEraser.setOnClickListener { selectTool(PhotoEditView.Mode.ERASE) }

        buildColorRow()
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) = onChange(progress)
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }

    private fun buildColorRow() {
        colorRow.removeAllViews()
        val density = resources.displayMetrics.density
        val size = (34 * density).toInt()
        val margin = (5 * density).toInt()
        penColors.forEach { c ->
            val v = View(this)
            val selected = c == selectedColor
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(if (selected) (4 * density).toInt() else 2, if (selected) Color.parseColor("#64B5F6") else Color.GRAY)
            }
            val lp = LinearLayout.LayoutParams(size, size)
            lp.setMargins(margin, 0, margin, 0)
            v.layoutParams = lp
            v.setOnClickListener {
                selectedColor = c
                buildColorRow()
                applyBrush()
            }
            colorRow.addView(v)
        }
    }

    private fun applyBrush() {
        val d = resources.displayMetrics.density
        editView.penColor = selectedColor
        if (editView.mode == PhotoEditView.Mode.ERASE) {
            editView.strokePx = eraserSizeDp * d
            editView.alphaPercent = eraserAlpha
        } else {
            editView.strokePx = penSizeDp * d
            editView.alphaPercent = penAlpha
        }
    }

    private fun selectTool(mode: PhotoEditView.Mode) {
        editView.mode = mode
        cropControls.visibility = if (mode == PhotoEditView.Mode.CROP) View.VISIBLE else View.GONE
        drawControls.visibility = if (mode == PhotoEditView.Mode.CROP) View.GONE else View.VISIBLE
        colorRow.visibility = if (mode == PhotoEditView.Mode.DRAW) View.VISIBLE else View.GONE
        toolCrop.alpha = if (mode == PhotoEditView.Mode.CROP) 1f else 0.5f
        toolPen.alpha = if (mode == PhotoEditView.Mode.DRAW) 1f else 0.5f
        toolEraser.alpha = if (mode == PhotoEditView.Mode.ERASE) 1f else 0.5f

        if (mode != PhotoEditView.Mode.CROP) {
            val dp = if (mode == PhotoEditView.Mode.ERASE) eraserSizeDp else penSizeDp
            val a = if (mode == PhotoEditView.Mode.ERASE) eraserAlpha else penAlpha
            sizeSeek.progress = (dp - 2).coerceIn(0, sizeSeek.max)
            alphaSeek.progress = (a - 5).coerceIn(0, alphaSeek.max)
            sizeLabel.text = "Boyut: $dp"
            alphaLabel.text = "Şeffaflık (opaklık): %$a"
        }
        applyBrush()
    }

    private fun openEditor() {
        val p = currentPhoto ?: return
        viewScreen.visibility = View.GONE
        editScreen.visibility = View.VISIBLE
        Thread {
            val bmp = PhotoScanner.loadBitmap(this, p.uri, 2400)
            runOnUiThread {
                if (bmp == null) {
                    Toast.makeText(this, "Fotoğraf düzenleme için açılamadı", Toast.LENGTH_SHORT).show()
                    editScreen.visibility = View.GONE
                    viewScreen.visibility = View.VISIBLE
                } else {
                    editView.setPhoto(bmp)
                    selectTool(PhotoEditView.Mode.DRAW)
                }
            }
        }.start()
    }

    private fun saveEdit() {
        val p = currentPhoto ?: return
        if (!editView.hasPhoto()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(p.uri))
                writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                return
            } catch (e: Exception) {
                // doğrudan yazmayı dene
            }
        }
        performSave()
    }

    private fun compressFormatFor(mime: String): Bitmap.CompressFormat = when {
        mime.contains("png") -> Bitmap.CompressFormat.PNG
        else -> Bitmap.CompressFormat.JPEG
    }

    private fun performSave() {
        val p = currentPhoto ?: return
        val bmp = editView.exportMerged() ?: return
        Thread {
            val ok = try {
                contentResolver.openOutputStream(p.uri, "wt")?.use { out ->
                    bmp.compress(compressFormatFor(p.mimeType), 92, out)
                } ?: false
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
                    editScreen.visibility = View.GONE
                    viewScreen.visibility = View.VISIBLE
                    scan { loadViewer() }
                } else {
                    Toast.makeText(this, "Kaydedilemedi", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
