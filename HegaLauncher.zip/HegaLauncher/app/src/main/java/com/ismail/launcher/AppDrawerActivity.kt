package com.ismail.launcher

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.Locale

class AppDrawerActivity : AppCompatActivity() {

    private class MenuEntry(val label: String, val action: () -> Unit)

    private lateinit var pager: ViewPager2
    private lateinit var pageAdapter: PageAdapter
    private lateinit var searchAdapter: AppAdapter
    private lateinit var indicatorContainer: LinearLayout

    private var allApps: List<AppInfo> = emptyList()
    private var currentGrid: List<GridItem> = emptyList()
    private var currentQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_app_drawer)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(0, bars.top + dp(8), 0, maxOf(bars.bottom, ime.bottom))
            insets
        }

        indicatorContainer = findViewById(R.id.pageIndicator)
        pager = findViewById(R.id.pager)
        pageAdapter = PageAdapter(
            pages = emptyList(),
            scope = LauncherPrefs.DRAWER,
            onAppTap = { app -> launchApp(app) },
            onAppLongPress = { app -> showAppOptions(app) },
            onFolderTap = { folderItem -> openFolder(folderItem) },
            onFolderLongPress = { folderItem -> showFolderOptions(folderItem) },
            onBackgroundLongPress = {}
        )
        pager.adapter = pageAdapter
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicatorActive(position)
            }
        })

        val results = findViewById<RecyclerView>(R.id.searchResults)
        results.layoutManager = GridLayoutManager(this, LauncherPrefs.getColumns(this, LauncherPrefs.DRAWER))
        searchAdapter = AppAdapter(
            items = emptyList(),
            scope = LauncherPrefs.DRAWER,
            onAppTap = { app -> launchApp(app) },
            onAppLongPress = { app -> showAppOptions(app) },
            onFolderTap = { folderItem -> openFolder(folderItem) },
            onFolderLongPress = { folderItem -> showFolderOptions(folderItem) }
        )
        results.adapter = searchAdapter

        findViewById<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = filter(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) {}
        })

        findViewById<View>(R.id.settingsButton).setOnClickListener {
            startActivity(SettingsActivity.intent(this, LauncherPrefs.DRAWER))
        }

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        val results = findViewById<RecyclerView>(R.id.searchResults)
        (results.layoutManager as? GridLayoutManager)?.spanCount = LauncherPrefs.getColumns(this, LauncherPrefs.DRAWER)
        loadApps()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showMenu(title: String?, entries: List<MenuEntry>) {
        val builder = AlertDialog.Builder(this)
        if (title != null) builder.setTitle(title)
        builder.setItems(entries.map { it.label }.toTypedArray()) { _, which -> entries[which].action() }
        builder.show()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        allApps = resolved.map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                activityName = it.activityInfo.name,
                icon = it.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        rebuildGrid()
    }

    private fun rebuildGrid() {
        val folders = LauncherPrefs.getFolders(this)
        val usedRefs = folders.flatMap { it.apps }.map { it.packageName to it.activityName }.toSet()
        val loneApps = allApps.filter { (it.packageName to it.activityName) !in usedRefs }

        val folderItems = folders.map { f ->
            val icons = f.apps.mapNotNull { ref ->
                allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
            }
            GridItem.FolderItem(f, icons)
        }
        val appItems = loneApps.map { GridItem.AppItem(it) }

        currentGrid = (folderItems + appItems).sortedBy {
            when (it) {
                is GridItem.FolderItem -> it.folder.name.lowercase(Locale.getDefault())
                is GridItem.AppItem -> it.app.label.lowercase(Locale.getDefault())
            }
        }
        paginate()
        if (currentQuery.isNotBlank()) searchAdapter.update(applyFilter(currentGrid, currentQuery))
    }

    private fun paginate() {
        val perPage = (LauncherPrefs.getColumns(this, LauncherPrefs.DRAWER) *
            LauncherPrefs.getRows(this, LauncherPrefs.DRAWER)).coerceAtLeast(1)
        val chunks = currentGrid.chunked(perPage)
        val pages = if (chunks.isEmpty()) listOf(emptyList()) else chunks
        pageAdapter.update(pages)
        buildIndicator(pages.size)
        if (pager.currentItem >= pages.size) pager.setCurrentItem(0, false)
    }

    private fun buildIndicator(count: Int) {
        indicatorContainer.removeAllViews()
        if (count <= 1) {
            indicatorContainer.visibility = View.GONE
            return
        }
        indicatorContainer.visibility = View.VISIBLE
        val size = dp(8)
        val margin = dp(4)
        for (i in 0 until count) {
            val dot = ImageView(this)
            dot.setImageResource(if (i == pager.currentItem) R.drawable.dot_active else R.drawable.dot_inactive)
            val params = LinearLayout.LayoutParams(size, size)
            params.setMargins(margin, 0, margin, 0)
            dot.layoutParams = params
            indicatorContainer.addView(dot)
        }
    }

    private fun updateIndicatorActive(active: Int) {
        for (i in 0 until indicatorContainer.childCount) {
            (indicatorContainer.getChildAt(i) as? ImageView)?.setImageResource(
                if (i == active) R.drawable.dot_active else R.drawable.dot_inactive
            )
        }
    }

    private fun applyFilter(items: List<GridItem>, q: String): List<GridItem> {
        if (q.isBlank()) return items
        val lq = q.lowercase(Locale.getDefault())
        return items.filter {
            when (it) {
                is GridItem.AppItem -> it.app.label.lowercase(Locale.getDefault()).contains(lq)
                is GridItem.FolderItem -> it.folder.name.lowercase(Locale.getDefault()).contains(lq) ||
                    it.icons.any { a -> a.label.lowercase(Locale.getDefault()).contains(lq) }
            }
        }
    }

    private fun filter(q: String) {
        currentQuery = q
        val results = findViewById<RecyclerView>(R.id.searchResults)
        if (q.isBlank()) {
            results.visibility = View.GONE
            pager.visibility = View.VISIBLE
            indicatorContainer.visibility = if (pageAdapter.itemCount > 1) View.VISIBLE else View.GONE
        } else {
            pager.visibility = View.GONE
            indicatorContainer.visibility = View.GONE
            results.visibility = View.VISIBLE
            searchAdapter.update(applyFilter(currentGrid, q))
        }
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Uygulama açılamadıysa sessizce geç
        }
    }

    // ---------- Uygulama seçenekleri ----------

    private fun isOnHome(app: AppInfo): Boolean =
        LauncherPrefs.getHomeItems(this).any {
            it is HomeEntry.AppEntry && it.ref.packageName == app.packageName && it.ref.activityName == app.activityName
        }

    private fun isInDock(app: AppInfo): Boolean =
        LauncherPrefs.getDock(this).any { it.packageName == app.packageName && it.activityName == app.activityName }

    private fun toggleHome(app: AppInfo, currentlyOnHome: Boolean) {
        val items = LauncherPrefs.getHomeItems(this)
        if (currentlyOnHome) {
            items.removeAll {
                it is HomeEntry.AppEntry && it.ref.packageName == app.packageName && it.ref.activityName == app.activityName
            }
        } else {
            items.add(HomeEntry.AppEntry(AppRef(app.packageName, app.activityName)))
        }
        LauncherPrefs.saveHomeItems(this, items)
    }

    private fun toggleDock(app: AppInfo, currentlyInDock: Boolean) {
        val dock = LauncherPrefs.getDock(this)
        if (currentlyInDock) {
            dock.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        } else {
            if (dock.size >= MAX_DOCK) dock.removeAt(0)
            dock.add(AppRef(app.packageName, app.activityName))
        }
        LauncherPrefs.saveDock(this, dock)
    }

    private fun showAppOptions(app: AppInfo) {
        val onHome = isOnHome(app)
        val inDock = isInDock(app)
        showMenu(
            app.label,
            listOf(
                MenuEntry("Uygulama bilgisi") {
                    val uri = Uri.fromParts("package", app.packageName, null)
                    try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) } catch (e: Exception) {}
                },
                MenuEntry(if (onHome) "Ana ekrandan çıkar" else "Ana ekrana ekle") { toggleHome(app, onHome) },
                MenuEntry(if (inDock) "Dock'tan çıkar" else "Dock'a ekle") { toggleDock(app, inDock) },
                MenuEntry("Klasöre taşı") { moveToFolder(app) },
                MenuEntry("Kaldır") {
                    val uri = Uri.fromParts("package", app.packageName, null)
                    try { startActivity(Intent(Intent.ACTION_DELETE, uri)) } catch (e: Exception) {}
                }
            )
        )
    }

    // ---------- Klasörler ----------

    private fun moveToFolder(app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val names = (folders.map { it.name } + "+ Yeni klasör").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Klasöre ekle")
            .setItems(names) { _, which ->
                if (which == folders.size) {
                    promptNewFolderName { name ->
                        val updated = folders + FolderInfo(name, mutableListOf(AppRef(app.packageName, app.activityName)))
                        LauncherPrefs.saveFolders(this, updated)
                        rebuildGrid()
                    }
                } else {
                    folders[which].apps.add(AppRef(app.packageName, app.activityName))
                    LauncherPrefs.saveFolders(this, folders)
                    rebuildGrid()
                }
            }
            .show()
    }

    private fun promptNewFolderName(onDone: (String) -> Unit) {
        val input = EditText(this)
        input.hint = "Klasör adı"
        AlertDialog.Builder(this)
            .setTitle("Yeni klasör")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) onDone(name)
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun isFolderOnHome(name: String): Boolean =
        LauncherPrefs.getHomeItems(this).any { it is HomeEntry.FolderEntry && it.folderName == name }

    private fun showFolderOptions(item: GridItem.FolderItem) {
        val onHome = isFolderOnHome(item.folder.name)
        showMenu(
            item.folder.name,
            listOf(
                MenuEntry(if (onHome) "Ana ekrandan çıkar" else "Ana ekrana ekle") {
                    val items = LauncherPrefs.getHomeItems(this)
                    if (onHome) items.removeAll { it is HomeEntry.FolderEntry && it.folderName == item.folder.name }
                    else items.add(HomeEntry.FolderEntry(item.folder.name))
                    LauncherPrefs.saveHomeItems(this, items)
                },
                MenuEntry("Klasörü sil") {
                    val folders = LauncherPrefs.getFolders(this).filter { it.name != item.folder.name }
                    LauncherPrefs.saveFolders(this, folders)
                    val items = LauncherPrefs.getHomeItems(this)
                    items.removeAll { it is HomeEntry.FolderEntry && it.folderName == item.folder.name }
                    LauncherPrefs.saveHomeItems(this, items)
                    rebuildGrid()
                }
            )
        )
    }

    private fun openFolder(item: GridItem.FolderItem) {
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val shape = LauncherPrefs.getIconShape(this, LauncherPrefs.DRAWER)
        item.icons.forEach { app ->
            val cellView = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            val icon = cellView.findViewById<ImageView>(R.id.icon)
            val label = cellView.findViewById<TextView>(R.id.label)
            icon.setImageDrawable(IconShaper.apply(this, app.icon, shape, dp(56)))
            label.text = app.label
            label.setTextColor(Color.WHITE)
            cellView.layoutParams = GridLayout.LayoutParams().apply {
                width = dp(76)
                height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            cellView.setOnClickListener { launchApp(app) }
            cellView.setOnLongClickListener { removeFromFolder(item.folder, app); true }
            grid.addView(cellView)
        }
        scroll.addView(grid)
        AlertDialog.Builder(this)
            .setTitle(item.folder.name)
            .setView(scroll)
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun removeFromFolder(folder: FolderInfo, app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val target = folders.find { it.name == folder.name } ?: return
        target.apps.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        val cleaned = if (target.apps.isEmpty()) folders.filter { it !== target } else folders
        LauncherPrefs.saveFolders(this, cleaned)
        rebuildGrid()
    }

    companion object {
        private const val MAX_DOCK = 5
    }
}
