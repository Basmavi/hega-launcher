package com.ismail.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SongAdapter(
    private var items: List<SongInfo>,
    private val onTap: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val art: ImageView = view.findViewById(R.id.art)
        val title: TextView = view.findViewById(R.id.title)
        val artist: TextView = view.findViewById(R.id.artist)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = items[position]
        holder.title.text = song.title
        holder.artist.text = song.artist
        holder.art.setImageResource(R.mipmap.ic_launcher)
        val tag = song.id
        holder.itemView.tag = tag
        val context = holder.itemView.context
        Thread {
            val bmp = MusicScanner.loadArt(context, song, 160)
            holder.itemView.post {
                if (holder.itemView.tag == tag && bmp != null) holder.art.setImageBitmap(bmp)
            }
        }.start()
        holder.itemView.setOnClickListener { onTap(holder.adapterPosition) }
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<SongInfo>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun itemAt(position: Int): SongInfo? = items.getOrNull(position)
}
