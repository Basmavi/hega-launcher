package com.ismail.launcher

import android.net.Uri

data class SongInfo(
    val id: Long,
    val title: String,
    val artist: String,
    val albumArtUri: Uri,
    val audioUri: Uri,
    val durationMs: Long
)

data class VolumeInfo(val label: String, val volumeName: String?, val available: Boolean)
