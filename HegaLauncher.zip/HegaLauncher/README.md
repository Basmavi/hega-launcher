# Hega Launcher (v4)

Tamamen yerel çalışan bir Android ana ekran launcher'ı.

## Bu sürümde yeni olanlar
- **Ana ekran ve Menü ayarları artık tamamen ayrı.** Ana ekranda boş alana uzun
  bas → "Ana ekran ayarları". Uygulama Menüsü'nde sağ üstteki ⚙ → "Menü ayarları".
  Simge boyutu, şekli, sütun/satır sayısı ikisinde de birbirinden bağımsız.
- **Dock'a ekle artık her iki yerde de var:** hem ana ekranda bir uygulamaya uzun
  basınca, hem Uygulama Menüsü'nde bir uygulamaya uzun basınca "Dock'a ekle/çıkar"
  seçeneği çıkıyor.
- **Dock rengi ve şeffaflığı ayarlanabiliyor:** Ana ekran ayarları → Dock bölümü.
  7 renk seçeneği + %0-100 opaklık kaydırıcısı.
- **Saat ve widget artık serbestçe taşınabiliyor/boyutlandırılabiliyor:**
  - Saatin üzerine uzun bas → "Sürükleyerek taşı" (parmağınla istediğin yere
    çek) ya da "Boyutu ayarla".
  - Widget'ın üzerine uzun bas → aynı şekilde taşı/boyutlandır, ya da kaldır.
  - Ana ekran ayarları'ndaki "Saat ve widget konumlarını sıfırla" ile eski
    haline dönebilirsin.
  - "Uygulamaların üst boşluğu" kaydırıcısıyla, ana ekrandaki uygulama
    ızgarasının nereden başlayacağını (saatin altından mı, hemen tepeden mi)
    ayarlayabilirsin.
- **Simge şekli düzeltmesi:** "Yuvarlak" artık gerçekten kareye tam oturan bir
  daire. Önceki sürümde bazı uygulamaların adaptif ikonları kendi köşeli
  maskesini koruyup köşeli görünüyordu; artık ikon katmanları doğrudan çizilip
  üzerine tam daire maskesi uygulanıyor.
- **Widget yükleme sorunları için düzeltmeler:**
  - Widget seçim listesinde artık hangi uygulamaya ait olduğu ve boyutu da
    yazıyor, bulması kolaylaşıyor.
  - Bağlama (bind) ve yapılandırma (configure) akışı, sistemin kendi widget
    host mekanizması üzerinden yürütülüyor — bazı widget'ların hiç
    yüklenmemesine sebep olan eski akış değiştirildi.
  - Bir widget gerçekten yüklenemezse artık sessizce hiçbir şey olmuyormuş
    gibi durmuyor, "Widget yüklenemedi" uyarısı çıkıyor ve yarım kalan kaydı
    temizleniyor.
  - Widget boyutu, sistemdeki gerçek piksel boyutuna göre widget'a doğru
    şekilde bildiriliyor (bazı widget'ların küçük/bozuk görünmesinin sebebi
    buydu).

## Genel özellikler
- Yatay kaydırmalı ana ekran + ayrı bir Uygulama Menüsü (dock'un sağındaki ⠿
  butonuna basarak açılır), her ikisi de sayfalı ve klasör destekli.
- Ana ekran ilk kurulumda boş başlar; istediğini Menü'den "Ana ekrana ekle"
  diyerek eklersin.
- Klasörler, widget, duvar kağıdı değiştirme.
- Ayarlar: simge şekli/boyutu, yazı boyutu/rengi, sütun/satır sayısı — ana ekran
  ve menü için ayrı ayrı; ayrıca ana ekrana özel saat ve dock ayarları.

## Kurulum / güncelleme
Sabit bir debug imzalama anahtarı kullanılıyor (app/debug.keystore, repoda),
versionCode her güncellemede artırıldığından eski kurulumun üzerine doğrudan
kurabilirsin.

1. Repoya bu zip'i yükle (eskisinin üzerine yazar).
2. **Actions → Build APK → Run workflow**.
3. Bitince Artifacts'tan `app-debug`'ı indir, `.apk`'yı kur.
4. **Ayarlar → Uygulamalar → Varsayılan uygulamalar → Ana ekran** → Hega Launcher
   (zaten seçiliyse tekrar seçmene gerek yok).

## Sınırlamalar
- Sayfalar arası sürükle-bırak yok, sıralama eklenme/alfabetik sıraya göre.
- Aynı anda yalnızca bir widget alanı var.
- İkon paketleri desteklenmiyor.

Bir sorun çıkarsa "Derle" adımının loglarında "e:" ile başlayan satırı (varsa)
ekran görüntüsü olarak gönder, en hızlı öyle buluruz.

## v6: Yerini değiştirme
Hem ana ekranda, hem Uygulama Menüsü'nde, hem dock'ta bir uygulama/klasöre uzun
basıp "Yerini değiştir" diyebilirsin. Sonra dokunduğun bir sonraki uygulama/klasör
ile yer değiştirir. Bunu istediğin kadar tekrarlayarak sıralamayı tamamen
istediğin gibi kurabilirsin. Değişiklikler kalıcı olarak kaydediliyor.

Not: Bu bir "sürükle-bırak" değil, "seç → hedefe dokun → takas et" şeklinde
çalışıyor; iki kere üst üste dokunarak taşıma yapıyorsun. Gerçek parmakla
sürükleme istersen ayrı bir istekte belirt, onu da ekleyebiliriz.

## Sırada ne var
Bu güncellemeyle birlikte istenenler arasında üç ayrı uygulama daha var:
**Hega Music**, **Hega Video**, **Hega Foto** — ve 5 dil desteği (İngilizce,
İspanyolca, Fransızca, Arapça, Farsça). Bunlar kapsamı çok büyük olduğu için
ayrı güncellemeler halinde geliyor.

## v6.1: Hega Music
Hega Launcher'ın içinde, ama hiçbir yerde (ana ekranda, Uygulama Menüsü'nde)
otomatik görünmeyen ayrı bir müzik ekranı: **Hega Music**.

**Nasıl açılır:**
- Ana ekranda ya da Menü'de boş alana uzun bas → "Ayarlar" → en üstte
  **"Hega Music'i aç"** butonu.
- Bir kere açtıktan sonra, Hega Music'in kendi **⋮** menüsünden
  **"Ana ekrana ekle"** diyerek ana ekrana da sabitleyebilirsin — o zaman bir
  daha Ayarlar'a girmene gerek kalmaz.

**Neler var:**
- **Tara** butonuna basınca hafıza izni ister (Android 13'te "Müzik ve ses"
  izni), izin verilince cihazdaki tüm şarkıları tarayıp kapak fotoğrafı +
  isimleriyle listeler.
- **⋮ menü → Depolama konumu:** Dahili hafıza / SD kart / USB (OTG) seçenekleri.
  Takılı olmayan bir birimi seçersen "Bu birim takılı değil" uyarısı çıkar;
  takılıysa o birimi tarar. (Not: SD kart ile OTG'yi ayırt etme Android'in
  kendi API'sinde net bir bayrakla desteklenmiyor; iki ayrı harici birim
  bulunursa birincisi SD kart, ikincisi OTG sayılıyor — cihazına göre ters
  çıkarsa haber ver, ona göre ayarlarız.)
- Bir şarkıya dokununca YouTube Music'e benzer bir oynatıcı açılır: kapak
  fotoğrafı, isim/sanatçı, ilerleme çubuğu, karıştır/geri/oynat-duraklat/ileri/
  tekrarla düğmeleri. Beğeni/beğenmeme satırı yok (istendiği gibi).
- Geri (⌄) ile kütüphaneye dönersin; müzik o sırada çalmaya devam eder (henüz
  arka planda bildirim/mini oynatıcı yok — ekran kapanırsa/uygulamadan tamamen
  çıkarsan çalma durur, bu bir sonraki geliştirme konusu olabilir).

**Düzenleme yok** (istendiği gibi) — sadece tarama, listeleme ve oynatma.
