package com.ismail.launcher

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Size

object VideoScanner {

    fun scan(context: Context): List<VideoInfo> {
        val out = mutableListOf<VideoInfo>()
        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_TAKEN,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DURATION
        )
        val hasRelPath = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        if (hasRelPath) projection.add(MediaStore.MediaColumns.RELATIVE_PATH)

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection.toTypedArray(),
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val takenCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_TAKEN)
                val addedCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val wCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val relCol = if (hasRelPath) c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH) else -1
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val taken = c.getLong(takenCol)
                    val added = c.getLong(addedCol)
                    out.add(
                        VideoInfo(
                            id = id,
                            uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                            displayName = c.getString(nameCol) ?: "",
                            mimeType = c.getString(mimeCol) ?: "video/*",
                            dateMillis = if (taken > 0) taken else added * 1000L,
                            sizeBytes = c.getLong(sizeCol),
                            width = c.getInt(wCol),
                            height = c.getInt(hCol),
                            durationMs = c.getLong(durCol),
                            relativePath = if (relCol >= 0) (c.getString(relCol) ?: "") else ""
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // izin yoksa ya da sorgu başarısızsa boş liste dön
        }
        return out
    }

    /** Liste küçük resmi. Arka plan iş parçacığında çağrılmalı. */
    fun loadThumb(context: Context, video: VideoInfo, w: Int, h: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(video.uri, Size(w, h), null)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Video.Thumbnails.getThumbnail(
                    context.contentResolver, video.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun formatSize(bytes: Long): String =
        if (bytes >= 1024L * 1024L * 1024L) "%.2f GB".format(bytes / 1024f / 1024f / 1024f)
        else if (bytes >= 1024L * 1024L) "%.1f MB".format(bytes / 1024f / 1024f)
        else "${bytes / 1024} KB"
}
