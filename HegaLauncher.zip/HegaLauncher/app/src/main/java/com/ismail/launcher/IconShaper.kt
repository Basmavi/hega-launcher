package com.ismail.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

object IconShaper {
    /**
     * source ikonunu istenen şekle göre maskeler. Kenarların pürüzsüz (anti-aliased)
     * çıkması için önce maske şekli çizilir, sonra ikon SRC_IN ile üzerine bindirilir.
     */
    fun apply(context: Context, source: Drawable, shape: String, size: Int = 144): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        when (shape) {
            "circle" -> path.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
            "squircle" -> path.addRoundRect(
                RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.3f, size * 0.3f, Path.Direction.CW
            )
            else -> path.addRoundRect(
                RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.14f, size * 0.14f, Path.Direction.CW
            )
        }
        canvas.drawPath(path, paint)

        val fresh = source.constantState?.newDrawable(context.resources)?.mutate() ?: source
        fresh.setBounds(0, 0, size, size)
        val iconBmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        fresh.draw(Canvas(iconBmp))

        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(iconBmp, 0f, 0f, paint)

        return BitmapDrawable(context.resources, bmp)
    }
}
