package com.ismail.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hega Video: videoları tarar, oynatır; silme ve hakkında bilgisi. Düzenleme yok. */
class VideoActivity : AppCompatActivity() {

    private lateinit var libraryScreen: View
    private lateinit var playerScreen: View
    private lateinit var scanBtn: Button
    private lateinit var permissionNotice: TextView
    private lateinit var videoAdapter: VideoAdapter
    private lateinit var videoView: VideoView
    private lateinit var videoTitle: TextView

    private var videos: List<VideoInfo> = emptyList()
    private var currentIndex = -1
    private val currentVideo: VideoInfo? get() = videos.getOrNull(currentIndex)

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionNotice.visibility = if (granted) View.GONE else View.VISIBLE
        if (granted) scan()
        else Toast.makeText(this, "İzin verilmeden videolar taranamaz", Toast.LENGTH_SHORT).show()
    }

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
            showLibrary()
            scan()
        } else {
            Toast.makeText(this, "Silme iptal edildi", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(ThemeHelper.appTheme(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)

        libraryScreen = findViewById(R.id.videoLibraryScreen)
        playerScreen = findViewById(R.id.videoPlayerScreen)
        scanBtn = findViewById(R.id.videoScanBtn)
        permissionNotice = findViewById(R.id.videoPermissionNotice)
        videoView = findViewById(R.id.videoView)
        videoTitle = findViewById(R.id.videoTitle)

        val list = findViewById<RecyclerView>(R.id.videoList)
        list.layoutManager = LinearLayoutManager(this)
        videoAdapter = VideoAdapter(emptyList()) { position -> openPlayer(position) }
        list.adapter = videoAdapter

        findViewById<TextView>(R.id.videoMenuBtn).setOnClickListener { showTopMenu() }
        scanBtn.setOnClickListener { ensurePermissionThenScan() }
        findViewById<View>(R.id.videoBack).setOnClickListener { showLibrary() }
        findViewById<View>(R.id.videoDelete).setOnClickListener { confirmDelete() }
        findViewById<View>(R.id.videoInfo).setOnClickListener { showInfo() }

        if (hasPermission()) scan()
    }

    override fun onPause() {
        super.onPause()
        if (playerScreen.visibility == View.VISIBLE) {
            try { videoView.pause() } catch (e: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { videoView.stopPlayback() } catch (e: Exception) {}
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (playerScreen.visibility == View.VISIBLE) showLibrary() else super.onBackPressed()
    }

    // ---------- İzin / tarama ----------

    private fun requiredPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, requiredPermission()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissionThenScan() {
        if (hasPermission()) scan() else permLauncher.launch(requiredPermission())
    }

    private fun scan() {
        scanBtn.isEnabled = false
        scanBtn.text = "Taranıyor…"
        Thread {
            val list = VideoScanner.scan(this)
            runOnUiThread {
                scanBtn.isEnabled = true
                scanBtn.text = "Tara"
                videos = list
                videoAdapter.update(list)
                if (list.isEmpty()) Toast.makeText(this, "Video bulunamadı", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun showLibrary() {
        try { videoView.stopPlayback() } catch (e: Exception) {}
        playerScreen.visibility = View.GONE
        libraryScreen.visibility = View.VISIBLE
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- Üst menü ----------

    private fun showTopMenu() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Ana ekrana ekle")) { _, _ -> addSelfToHome() }
            .show()
    }

    private fun addSelfToHome() {
        val items = LauncherPrefs.getHomeItems(this)
        val already = items.any {
            it is HomeEntry.AppEntry && it.ref.packageName == packageName && it.ref.activityName == VideoActivity::class.java.name
        }
        if (already) {
            Toast.makeText(this, "Hega Video zaten ana ekranda", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeEntry.AppEntry(AppRef(packageName, VideoActivity::class.java.name)))
        LauncherPrefs.saveHomeItems(this, items)
        Toast.makeText(this, "Hega Video ana ekrana eklendi", Toast.LENGTH_SHORT).show()
    }

    // ---------- Oynatıcı ----------

    private fun openPlayer(position: Int) {
        val video = videos.getOrNull(position) ?: return
        currentIndex = position
        libraryScreen.visibility = View.GONE
        playerScreen.visibility = View.VISIBLE
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        videoTitle.text = video.displayName

        val controller = MediaController(this)
        controller.setAnchorView(videoView)
        videoView.setMediaController(controller)
        videoView.setOnPreparedListener { videoView.start() }
        videoView.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Bu video oynatılamadı", Toast.LENGTH_SHORT).show()
            true
        }
        videoView.setVideoURI(video.uri)
    }

    // ---------- Sil / Hakkında ----------

    private fun showInfo() {
        val v = currentVideo ?: return
        val date = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("tr")).format(Date(v.dateMillis))
        val lines = mutableListOf(
            "Ad: ${v.displayName}",
            "Çözünürlük: ${v.width} × ${v.height}",
            "Süre: ${VideoScanner.formatDuration(v.durationMs)}",
            "Dosya boyutu: ${VideoScanner.formatSize(v.sizeBytes)}",
            "Tarih: $date",
            "Tür: ${v.mimeType}"
        )
        if (v.relativePath.isNotEmpty()) lines.add("Konum: ${v.relativePath}")
        AlertDialog.Builder(this)
            .setTitle("Hakkında")
            .setMessage(lines.joinToString("\n"))
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun confirmDelete() {
        val v = currentVideo ?: return
        AlertDialog.Builder(this)
            .setTitle("Sil")
            .setMessage("${v.displayName} silinsin mi?")
            .setPositiveButton("Sil") { _, _ -> deleteCurrentVideo() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun deleteCurrentVideo() {
        val v = currentVideo ?: return
        try { videoView.pause() } catch (e: Exception) {}
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(this, "Silinemedi", Toast.LENGTH_SHORT).show()
            }
        } else {
            try {
                contentResolver.delete(v.uri, null, null)
                Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
                showLibrary()
                scan()
            } catch (e: Exception) {
                Toast.makeText(this, "Silinemedi (izin gerekebilir)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
