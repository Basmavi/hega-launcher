package com.ismail.launcher

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.storage.StorageManager
import android.provider.MediaStore
import android.util.Size

object MusicScanner {

    /** Dahili hafıza / SD kart / USB (OTG) birimlerini listeler. */
    fun listVolumes(context: Context): List<VolumeInfo> {
        val sm = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
        val volumes = try { sm?.storageVolumes.orEmpty() } catch (e: Exception) { emptyList() }
        val primary = volumes.find { it.isPrimary }
        val others = volumes.filter { !it.isPrimary }
        val sd = others.getOrNull(0)
        val otg = others.getOrNull(1)
        return listOf(
            VolumeInfo("Dahili hafıza", mediaStoreName(primary), primary != null),
            VolumeInfo("SD kart", mediaStoreName(sd), sd != null),
            VolumeInfo("USB (OTG)", mediaStoreName(otg), otg != null)
        )
    }

    private fun mediaStoreName(v: android.os.storage.StorageVolume?): String? {
        if (v == null) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { v.mediaStoreVolumeName } catch (e: Exception) { null }
        } else null
    }

    /** volumeName null ise genel harici depoyu (MediaStore'un gördüğü her şeyi) tarar. */
    fun scan(context: Context, volumeName: String?): List<SongInfo> {
        val uri = if (volumeName != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { MediaStore.Audio.Media.getContentUri(volumeName) } catch (e: Exception) { MediaStore.Audio.Media.EXTERNAL_CONTENT_URI }
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION
        )
        val out = mutableListOf<SongInfo>()
        try {
            context.contentResolver.query(
                uri, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val songUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val albumId = c.getLong(albumIdCol)
                    val artUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
                    out.add(
                        SongInfo(
                            id = id,
                            title = c.getString(titleCol) ?: "Bilinmeyen",
                            artist = c.getString(artistCol) ?: "",
                            albumArtUri = artUri,
                            audioUri = songUri,
                            durationMs = c.getLong(durCol)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // izin yoksa ya da sorgu başarısızsa boş liste dön
        }
        return out
    }

    /** Arka plan iş parçacığından çağrılmalı; ağır bir işlem. */
    fun loadArt(context: Context, song: SongInfo, sizePx: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(song.audioUri, Size(sizePx, sizePx), null)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(context.contentResolver, song.albumArtUri)
            }
        } catch (e: Exception) {
            null
        }
    }
}
