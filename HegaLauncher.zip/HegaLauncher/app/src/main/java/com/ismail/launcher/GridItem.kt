package com.ismail.launcher

data class AppRef(val packageName: String, val activityName: String)

data class FolderInfo(var name: String, val apps: MutableList<AppRef>)

data class HomeEntry(
    val type: String, // "app" ya da "folder"
    val packageName: String? = null,
    val activityName: String? = null,
    val folderName: String? = null
)

sealed class GridItem {
    data class AppItem(val app: AppInfo) : GridItem()
    data class FolderItem(val folder: FolderInfo, val icons: List<AppInfo>) : GridItem()
}
