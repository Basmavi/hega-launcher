package com.ismail.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Fotoğraf + şeffaf bir çizim katmanı tutar.
 *  - CROP : sürüklenebilir kırpma dikdörtgeni
 *  - DRAW : kalem (renk, boyut, şeffaflık ayarlı)
 *  - ERASE: silgi, yalnızca çizim katmanını siler (boyut, güç ayarlı)
 */
class PhotoEditView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Mode { CROP, DRAW, ERASE }

    var mode: Mode = Mode.DRAW
        set(value) {
            field = value
            invalidate()
        }

    var penColor: Int = Color.RED

    /** Ekran pikseli cinsinden kalem/silgi kalınlığı. */
    var strokePx: Float = 12f

    /** 5..100 */
    var alphaPercent: Int = 100

    private var photo: Bitmap? = null
    private var overlay: Bitmap? = null
    private var overlayCanvas: Canvas? = null
    private var cropRect: RectF? = null

    private val currentPath = Path()
    private var lastX = 0f
    private var lastY = 0f
    private var activeHandle = -1

    private val dimPaint = Paint().apply { color = Color.parseColor("#AA000000") }
    private val framePaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    fun hasPhoto(): Boolean = photo != null

    fun setPhoto(bmp: Bitmap) {
        photo = bmp
        overlay = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        overlayCanvas = Canvas(overlay!!)
        cropRect = RectF(bmp.width * 0.08f, bmp.height * 0.08f, bmp.width * 0.92f, bmp.height * 0.92f)
        currentPath.reset()
        invalidate()
    }

    fun clearDrawing() {
        overlay?.eraseColor(Color.TRANSPARENT)
        invalidate()
    }

    /** Fotoğraf + çizimlerin birleşimi (tam çözünürlük, çalışma boyutunda). */
    fun exportMerged(): Bitmap? {
        val p = photo ?: return null
        val out = Bitmap.createBitmap(p.width, p.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(p, 0f, 0f, null)
        overlay?.let { c.drawBitmap(it, 0f, 0f, null) }
        return out
    }

    /** Kırpma dikdörtgenini uygular; çizimler fotoğrafa işlenir. */
    fun commitCrop() {
        val r = cropRect ?: return
        val merged = exportMerged() ?: return
        val l = r.left.toInt().coerceIn(0, merged.width - 1)
        val t = r.top.toInt().coerceIn(0, merged.height - 1)
        val w = r.width().toInt().coerceIn(1, merged.width - l)
        val h = r.height().toInt().coerceIn(1, merged.height - t)
        setPhoto(Bitmap.createBitmap(merged, l, t, w, h))
    }

    // ---------- Koordinat dönüşümleri ----------

    private fun fitScale(): Float {
        val p = photo ?: return 1f
        if (width == 0 || height == 0) return 1f
        return minOf(width / p.width.toFloat(), height / p.height.toFloat())
    }

    private fun offsetX(): Float {
        val p = photo ?: return 0f
        return (width - p.width * fitScale()) / 2f
    }

    private fun offsetY(): Float {
        val p = photo ?: return 0f
        return (height - p.height * fitScale()) / 2f
    }

    private fun viewToPhoto(x: Float, y: Float): PointF {
        val s = fitScale()
        return PointF((x - offsetX()) / s, (y - offsetY()) / s)
    }

    private fun photoToView(x: Float, y: Float): PointF {
        val s = fitScale()
        return PointF(x * s + offsetX(), y * s + offsetY())
    }

    // ---------- Çizim ----------

    private fun alpha255(): Int = (alphaPercent.coerceIn(5, 100) * 255 / 100)

    private fun penPaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = strokePx / fitScale()
        color = penColor
        alpha = alpha255()
    }

    private fun eraserPaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = strokePx / fitScale()
        color = Color.BLACK
        alpha = alpha255()
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    override fun onDraw(canvas: Canvas) {
        val p = photo ?: return
        val s = fitScale()
        canvas.save()
        canvas.translate(offsetX(), offsetY())
        canvas.scale(s, s)
        canvas.drawBitmap(p, 0f, 0f, null)
        overlay?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        if (mode == Mode.DRAW && !currentPath.isEmpty) {
            canvas.drawPath(currentPath, penPaint())
        }
        canvas.restore()

        if (mode == Mode.CROP) {
            val r = cropRect ?: return
            val tl = photoToView(r.left, r.top)
            val br = photoToView(r.right, r.bottom)
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRect(0f, 0f, w, tl.y, dimPaint)
            canvas.drawRect(0f, br.y, w, h, dimPaint)
            canvas.drawRect(0f, tl.y, tl.x, br.y, dimPaint)
            canvas.drawRect(br.x, tl.y, w, br.y, dimPaint)
            canvas.drawRect(tl.x, tl.y, br.x, br.y, framePaint)
            val hr = 18f
            canvas.drawCircle(tl.x, tl.y, hr, handlePaint)
            canvas.drawCircle(br.x, tl.y, hr, handlePaint)
            canvas.drawCircle(tl.x, br.y, hr, handlePaint)
            canvas.drawCircle(br.x, br.y, hr, handlePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (photo == null) return false
        when (mode) {
            Mode.CROP -> handleCropTouch(event)
            Mode.DRAW, Mode.ERASE -> handleDrawTouch(event)
        }
        return true
    }

    private fun handleDrawTouch(event: MotionEvent) {
        val oc = overlayCanvas ?: return
        val pt = viewToPhoto(event.x, event.y)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = pt.x
                lastY = pt.y
                if (mode == Mode.DRAW) {
                    currentPath.reset()
                    currentPath.moveTo(pt.x, pt.y)
                } else {
                    oc.drawLine(pt.x, pt.y, pt.x + 0.01f, pt.y, eraserPaint())
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == Mode.DRAW) {
                    currentPath.quadTo(lastX, lastY, (lastX + pt.x) / 2f, (lastY + pt.y) / 2f)
                } else {
                    oc.drawLine(lastX, lastY, pt.x, pt.y, eraserPaint())
                }
                lastX = pt.x
                lastY = pt.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.DRAW) {
                    currentPath.lineTo(lastX + 0.01f, lastY)
                    oc.drawPath(currentPath, penPaint())
                    currentPath.reset()
                }
                invalidate()
            }
        }
    }

    private fun handleCropTouch(event: MotionEvent) {
        val r = cropRect ?: return
        val p = photo ?: return
        val pt = viewToPhoto(event.x, event.y)
        val tl = photoToView(r.left, r.top)
        val br = photoToView(r.right, r.bottom)
        val slop = 48.0
        val minSize = 24f
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeHandle = when {
                    hypot((event.x - tl.x).toDouble(), (event.y - tl.y).toDouble()) < slop -> 0
                    hypot((event.x - br.x).toDouble(), (event.y - tl.y).toDouble()) < slop -> 1
                    hypot((event.x - tl.x).toDouble(), (event.y - br.y).toDouble()) < slop -> 2
                    hypot((event.x - br.x).toDouble(), (event.y - br.y).toDouble()) < slop -> 3
                    event.x >= tl.x && event.x <= br.x && event.y >= tl.y && event.y <= br.y -> 4
                    else -> -1
                }
                lastX = pt.x
                lastY = pt.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = pt.x - lastX
                val dy = pt.y - lastY
                val pw = p.width.toFloat()
                val ph = p.height.toFloat()
                when (activeHandle) {
                    0 -> {
                        r.left = (r.left + dx).coerceIn(0f, r.right - minSize)
                        r.top = (r.top + dy).coerceIn(0f, r.bottom - minSize)
                    }
                    1 -> {
                        r.right = (r.right + dx).coerceIn(r.left + minSize, pw)
                        r.top = (r.top + dy).coerceIn(0f, r.bottom - minSize)
                    }
                    2 -> {
                        r.left = (r.left + dx).coerceIn(0f, r.right - minSize)
                        r.bottom = (r.bottom + dy).coerceIn(r.top + minSize, ph)
                    }
                    3 -> {
                        r.right = (r.right + dx).coerceIn(r.left + minSize, pw)
                        r.bottom = (r.bottom + dy).coerceIn(r.top + minSize, ph)
                    }
                    4 -> {
                        val w = r.width()
                        val h = r.height()
                        val nl = (r.left + dx).coerceIn(0f, pw - w)
                        val nt = (r.top + dy).coerceIn(0f, ph - h)
                        r.set(nl, nt, nl + w, nt + h)
                    }
                }
                lastX = pt.x
                lastY = pt.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> activeHandle = -1
        }
    }
}
