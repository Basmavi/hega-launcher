package com.ismail.launcher

import android.content.Context
import android.graphics.Color

/** Beyaz / siyah tema seçimi. Seçim LauncherPrefs'te saklanır. */
object ThemeHelper {
    fun isDark(context: Context): Boolean = LauncherPrefs.getTheme(context) == LauncherPrefs.THEME_DARK

    /** Ayarlar, Music, Photos, Video ekranları için. */
    fun appTheme(context: Context): Int =
        if (isDark(context)) R.style.Theme_HegaAppDark else R.style.Theme_HegaAppLight

    /** Ana ekran ve Menü için (duvar kağıdı görünür, sadece diyaloglar değişir). */
    fun launcherTheme(context: Context): Int =
        if (isDark(context)) R.style.Theme_HegaLauncher else R.style.Theme_HegaLauncherLight

    /** Diyalog içindeki elle renklendirilen yazılar için. */
    fun dialogTextColor(context: Context): Int = if (isDark(context)) Color.WHITE else Color.BLACK
}
