package com.ismail.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MusicActivity : AppCompatActivity() {

    private class MenuEntry(val label: String, val action: () -> Unit)

    private lateinit var libraryScreen: View
    private lateinit var playerScreen: View
    private lateinit var scanBtn: Button
    private lateinit var permissionNotice: TextView
    private lateinit var songAdapter: SongAdapter

    private lateinit var art: ImageView
    private lateinit var songTitle: TextView
    private lateinit var songArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var curTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView
    private lateinit var playPauseBtn: TextView

    private var songs: List<SongInfo> = emptyList()
    private var currentIndex = -1
    private var selectedVolumeName: String? = null
    private var mediaPlayer: MediaPlayer? = null
    private var shuffleOn = false
    private var repeatOn = false
    private var seeking = false

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressTick = object : Runnable {
        override fun run() {
            val mp = mediaPlayer
            if (mp != null && !seeking) {
                try {
                    seek.progress = mp.currentPosition
                    curTime.text = formatTime(mp.currentPosition.toLong())
                } catch (e: Exception) {}
            }
            progressHandler.postDelayed(this, 500)
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionNotice.visibility = if (granted) View.GONE else View.VISIBLE
        if (granted) scan(selectedVolumeName)
        else Toast.makeText(this, "İzin verilmeden müzikler taranamaz", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)

        libraryScreen = findViewById(R.id.libraryScreen)
        playerScreen = findViewById(R.id.playerScreen)
        scanBtn = findViewById(R.id.scanBtn)
        permissionNotice = findViewById(R.id.permissionNotice)

        val list = findViewById<RecyclerView>(R.id.songList)
        list.layoutManager = LinearLayoutManager(this)
        songAdapter = SongAdapter(emptyList()) { position -> openPlayer(position) }
        list.adapter = songAdapter

        findViewById<TextView>(R.id.menuBtn).setOnClickListener { showTopMenu() }
        scanBtn.setOnClickListener { ensurePermissionThenScan() }

        art = findViewById(R.id.art)
        songTitle = findViewById(R.id.songTitle)
        songArtist = findViewById(R.id.songArtist)
        seek = findViewById(R.id.seek)
        curTime = findViewById(R.id.curTime)
        totalTime = findViewById(R.id.totalTime)
        shuffleBtn = findViewById(R.id.shuffleBtn)
        repeatBtn = findViewById(R.id.repeatBtn)
        playPauseBtn = findViewById(R.id.playPauseBtn)

        findViewById<TextView>(R.id.backBtn).setOnClickListener {
            playerScreen.visibility = View.GONE
            libraryScreen.visibility = View.VISIBLE
        }
        playPauseBtn.setOnClickListener { togglePlayPause() }
        findViewById<TextView>(R.id.prevBtn).setOnClickListener { previous() }
        findViewById<TextView>(R.id.nextBtn).setOnClickListener { next() }
        shuffleBtn.setOnClickListener {
            shuffleOn = !shuffleOn
            shuffleBtn.alpha = if (shuffleOn) 1f else 0.5f
        }
        repeatBtn.setOnClickListener {
            repeatOn = !repeatOn
            repeatBtn.alpha = if (repeatOn) 1f else 0.5f
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) curTime.text = formatTime(progress.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                mediaPlayer?.seekTo(sb?.progress ?: 0)
            }
        })

        if (hasPermission()) scan(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        progressHandler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun requiredPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, requiredPermission()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissionThenScan() {
        if (hasPermission()) scan(selectedVolumeName) else permLauncher.launch(requiredPermission())
    }

    private fun scan(volumeName: String?) {
        scanBtn.isEnabled = false
        scanBtn.text = "Taranıyor…"
        Thread {
            val list = MusicScanner.scan(this, volumeName)
            runOnUiThread {
                scanBtn.isEnabled = true
                scanBtn.text = "Tara"
                songs = list
                songAdapter.update(list)
                if (list.isEmpty()) Toast.makeText(this, "Müzik bulunamadı", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun showMenu(title: String?, entries: List<MenuEntry>) {
        val b = AlertDialog.Builder(this)
        if (title != null) b.setTitle(title)
        b.setItems(entries.map { it.label }.toTypedArray()) { _, which -> entries[which].action() }
        b.show()
    }

    private fun showTopMenu() {
        showMenu(
            null,
            listOf(
                MenuEntry("Depolama konumu") { showVolumePicker() },
                MenuEntry("Ana ekrana ekle") { addSelfToHome() }
            )
        )
    }

    private fun showVolumePicker() {
        val volumes = MusicScanner.listVolumes(this)
        AlertDialog.Builder(this)
            .setTitle("Depolama konumu")
            .setItems(volumes.map { it.label }.toTypedArray()) { _, which ->
                val v = volumes[which]
                if (!v.available) {
                    Toast.makeText(this, "Bu birim takılı değil", Toast.LENGTH_SHORT).show()
                } else {
                    selectedVolumeName = v.volumeName
                    ensurePermissionThenScan()
                }
            }
            .show()
    }

    private fun addSelfToHome() {
        val items = LauncherPrefs.getHomeItems(this)
        val already = items.any {
            it is HomeEntry.AppEntry && it.ref.packageName == packageName && it.ref.activityName == MusicActivity::class.java.name
        }
        if (already) {
            Toast.makeText(this, "Hega Music zaten ana ekranda", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeEntry.AppEntry(AppRef(packageName, MusicActivity::class.java.name)))
        LauncherPrefs.saveHomeItems(this, items)
        Toast.makeText(this, "Hega Music ana ekrana eklendi", Toast.LENGTH_SHORT).show()
    }

    // ---------- Oynatıcı ----------

    private fun openPlayer(position: Int) {
        if (position < 0 || position >= songs.size) return
        libraryScreen.visibility = View.GONE
        playerScreen.visibility = View.VISIBLE
        playSong(position)
    }

    private fun playSong(index: Int) {
        val song = songs.getOrNull(index) ?: return
        currentIndex = index
        mediaPlayer?.release()
        mediaPlayer = null
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, song.audioUri)
            mp.setOnPreparedListener {
                it.start()
                seek.max = it.duration
                totalTime.text = formatTime(it.duration.toLong())
                playPauseBtn.text = "❚❚"
            }
            mp.setOnCompletionListener {
                if (repeatOn) playSong(currentIndex) else next()
            }
            mp.prepareAsync()
            mediaPlayer = mp
        } catch (e: Exception) {
            Toast.makeText(this, "Bu şarkı oynatılamadı", Toast.LENGTH_SHORT).show()
        }

        songTitle.text = song.title
        songArtist.text = song.artist
        art.setImageResource(R.mipmap.ic_launcher)
        Thread {
            val bmp = MusicScanner.loadArt(this, song, 560)
            runOnUiThread { if (bmp != null && currentIndex == index) art.setImageBitmap(bmp) }
        }.start()

        progressHandler.removeCallbacks(progressTick)
        progressHandler.post(progressTick)
    }

    private fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                playPauseBtn.text = "▶"
            } else {
                mp.start()
                playPauseBtn.text = "❚❚"
            }
        } catch (e: Exception) {}
    }

    private fun next() {
        if (songs.isEmpty()) return
        val nextIndex = if (shuffleOn) {
            if (songs.size == 1) 0 else {
                var r: Int
                do { r = (0 until songs.size).random() } while (r == currentIndex)
                r
            }
        } else {
            if (currentIndex + 1 < songs.size) currentIndex + 1 else 0
        }
        playSong(nextIndex)
    }

    private fun previous() {
        if (songs.isEmpty()) return
        val prevIndex = if (currentIndex - 1 >= 0) currentIndex - 1 else songs.size - 1
        playSong(prevIndex)
    }

    private fun formatTime(ms: Long): String {
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return "%d:%02d".format(m, s)
    }
}
