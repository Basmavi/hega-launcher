package com.ismail.launcher

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Hega Browser: tek sekmeli, WebView tabanlı tarayıcı. */
class BrowserActivity : AppCompatActivity() {

    private class MenuEntry(val label: String, val action: () -> Unit)

    private lateinit var webView: WebView
    private lateinit var urlField: EditText
    private lateinit var progress: ProgressBar
    private lateinit var reloadBtn: TextView
    private lateinit var navBack: TextView
    private lateinit var navForward: TextView
    private lateinit var navBookmark: TextView
    private lateinit var fullscreenHolder: FrameLayout
    private lateinit var topBar: View
    private lateinit var bottomBar: View

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var defaultUserAgent: String = ""
    private var loading = false

    private val fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val results = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        fileCallback?.onReceiveValue(results)
        fileCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(ThemeHelper.appTheme(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)

        webView = findViewById(R.id.webView)
        urlField = findViewById(R.id.urlField)
        progress = findViewById(R.id.browserProgress)
        reloadBtn = findViewById(R.id.reloadBtn)
        navBack = findViewById(R.id.navBack)
        navForward = findViewById(R.id.navForward)
        navBookmark = findViewById(R.id.navBookmark)
        fullscreenHolder = findViewById(R.id.fullscreenHolder)
        topBar = findViewById(R.id.browserTopBar)
        bottomBar = findViewById(R.id.browserBottomBar)

        setupWebView()
        setupBars()

        val fromIntent = intent?.dataString
        if (fromIntent != null && (fromIntent.startsWith("http://") || fromIntent.startsWith("https://"))) {
            webView.loadUrl(fromIntent)
        } else {
            webView.loadUrl(BrowserStore.homeUrl(this))
        }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (e: Exception) {
            // yoksay
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> exitFullscreen()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }

    // ---------- Kurulum ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        defaultUserAgent = s.userAgentString
        applyDesktopMode(BrowserStore.isDesktop(this), false)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return handleUrl(url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                setLoading(true)
                if (url != null) updateUrlField(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                setLoading(false)
                if (url != null) {
                    updateUrlField(url)
                    BrowserStore.addHistory(this@BrowserActivity, view?.title ?: url, url)
                }
                updateNavState()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                enterFullscreen(view, callback)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }
    }

    private fun setupBars() {
        urlField.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                webView.loadUrl(BrowserStore.resolveInput(this, urlField.text.toString()))
                urlField.clearFocus()
                hideKeyboard()
                true
            } else {
                false
            }
        }
        reloadBtn.setOnClickListener {
            if (loading) webView.stopLoading() else webView.reload()
        }
        navBack.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        navForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        findViewById<View>(R.id.navHome).setOnClickListener { webView.loadUrl(BrowserStore.homeUrl(this)) }
        navBookmark.setOnClickListener { toggleBookmark() }
        findViewById<View>(R.id.navMenu).setOnClickListener { showMenu() }
        updateNavState()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(urlField.windowToken, 0)
    }

    // ---------- Durum ----------

    private fun setLoading(v: Boolean) {
        loading = v
        reloadBtn.text = if (v) "✕" else "↻"
    }

    private fun updateUrlField(url: String) {
        if (!urlField.hasFocus()) urlField.setText(url)
    }

    private fun updateNavState() {
        navBack.alpha = if (webView.canGoBack()) 1f else 0.35f
        navForward.alpha = if (webView.canGoForward()) 1f else 0.35f
        val url = webView.url
        val marked = url != null && BrowserStore.getBookmarks(this).any { it.url == url }
        navBookmark.text = if (marked) "★" else "☆"
    }

    // ---------- Bağlantı yönlendirme ----------

    /** true döndürürsek WebView yüklemez. http(s) dışındakiler ilgili uygulamaya verilir. */
    private fun handleUrl(url: String): Boolean {
        val lower = url.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) return false
        if (lower.startsWith("about:")) return false
        if (lower.startsWith("javascript:") || lower.startsWith("data:") ||
            lower.startsWith("file:") || lower.startsWith("content:")
        ) return true
        try {
            val intent = if (lower.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null
            intent.selector = null
            startActivity(intent)
        } catch (e: Exception) {
            // bu bağlantıyı açabilecek uygulama yok
        }
        return true
    }

    // ---------- Tam ekran video ----------

    private fun enterFullscreen(view: View?, callback: WebChromeClient.CustomViewCallback?) {
        if (view == null) return
        if (customView != null) {
            callback?.onCustomViewHidden()
            return
        }
        customView = view
        customViewCallback = callback
        fullscreenHolder.addView(
            view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        fullscreenHolder.visibility = View.VISIBLE
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        try {
            WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        } catch (e: Exception) {
            // yoksay
        }
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        fullscreenHolder.removeView(v)
        fullscreenHolder.visibility = View.GONE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        try {
            WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        } catch (e: Exception) {
            // yoksay
        }
    }

    // ---------- İndirme ----------

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mimeType != null) req.setMimeType(mimeType)
            if (userAgent != null) req.addRequestHeader("User-Agent", userAgent)
            val cookie = CookieManager.getInstance().getCookie(url)
            if (cookie != null) req.addRequestHeader("Cookie", cookie)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            Toast.makeText(this, "İndiriliyor: $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "İndirme başlatılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Masaüstü modu ----------

    private fun applyDesktopMode(on: Boolean, reload: Boolean) {
        val s = webView.settings
        s.userAgentString = if (on) DESKTOP_UA else defaultUserAgent
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        if (reload) webView.reload()
    }

    // ---------- Yer imleri / geçmiş ----------

    private fun toggleBookmark() {
        val url = webView.url ?: return
        val list = BrowserStore.getBookmarks(this)
        val idx = list.indexOfFirst { it.url == url }
        if (idx >= 0) {
            list.removeAt(idx)
            Toast.makeText(this, "Yer imi kaldırıldı", Toast.LENGTH_SHORT).show()
        } else {
            list.add(0, BrowserStore.Entry(webView.title ?: url, url))
            Toast.makeText(this, "Yer imi eklendi", Toast.LENGTH_SHORT).show()
        }
        BrowserStore.saveBookmarks(this, list)
        updateNavState()
    }

    private fun showBookmarks() {
        val list = BrowserStore.getBookmarks(this)
        if (list.isEmpty()) {
            Toast.makeText(this, "Henüz yer imi yok", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = list.map { if (it.title.isBlank()) it.url else it.title }.toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Yer imleri (silmek için uzun bas)")
            .setItems(labels) { _, which -> webView.loadUrl(list[which].url) }
            .setNegativeButton("Kapat", null)
            .create()
        dialog.show()
        dialog.listView.setOnItemLongClickListener { _, _, position, _ ->
            list.removeAt(position)
            BrowserStore.saveBookmarks(this, list)
            dialog.dismiss()
            updateNavState()
            Toast.makeText(this, "Yer imi silindi", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun showHistory() {
        val list = BrowserStore.getHistory(this)
        if (list.isEmpty()) {
            Toast.makeText(this, "Geçmiş boş", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = list.map { if (it.title.isBlank()) it.url else it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Geçmiş")
            .setItems(labels) { _, which -> webView.loadUrl(list[which].url) }
            .setNeutralButton("Geçmişi temizle") { _, _ ->
                BrowserStore.clearHistory(this)
                Toast.makeText(this, "Geçmiş temizlendi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    // ---------- Menü ----------

    private fun showMenu() {
        val desktop = BrowserStore.isDesktop(this)
        val entries = listOf(
            MenuEntry("Yer imleri") { showBookmarks() },
            MenuEntry("Geçmiş") { showHistory() },
            MenuEntry("İndirmeler") {
                try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) {}
            },
            MenuEntry(if (desktop) "Masaüstü sitesi: açık (kapat)" else "Masaüstü sitesi: kapalı (aç)") {
                BrowserStore.setDesktop(this, !desktop)
                applyDesktopMode(!desktop, true)
            },
            MenuEntry("Arama motoru: ${BrowserStore.engineLabel(this)}") { showEnginePicker() },
            MenuEntry("Sayfayı paylaş") { sharePage() },
            MenuEntry("Ana ekrana ekle") { addSelfToHome() },
            MenuEntry("Tarama verilerini temizle") { clearBrowsingData() }
        )
        AlertDialog.Builder(this)
            .setItems(entries.map { it.label }.toTypedArray()) { _, which -> entries[which].action() }
            .show()
    }

    private fun showEnginePicker() {
        AlertDialog.Builder(this)
            .setTitle("Arama motoru")
            .setItems(BrowserStore.ENGINE_LABELS.toTypedArray()) { _, which ->
                BrowserStore.setEngine(this, BrowserStore.ENGINE_IDS[which])
                Toast.makeText(this, "Arama motoru: ${BrowserStore.ENGINE_LABELS[which]}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun sharePage() {
        val url = webView.url ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        try {
            startActivity(Intent.createChooser(intent, "Paylaş"))
        } catch (e: Exception) {
            Toast.makeText(this, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addSelfToHome() {
        val items = LauncherPrefs.getHomeItems(this)
        val already = items.any {
            it is HomeEntry.AppEntry && it.ref.packageName == packageName && it.ref.activityName == BrowserActivity::class.java.name
        }
        if (already) {
            Toast.makeText(this, "Hega Browser zaten ana ekranda", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeEntry.AppEntry(AppRef(packageName, BrowserActivity::class.java.name)))
        LauncherPrefs.saveHomeItems(this, items)
        Toast.makeText(this, "Hega Browser ana ekrana eklendi", Toast.LENGTH_SHORT).show()
    }

    private fun clearBrowsingData() {
        AlertDialog.Builder(this)
            .setTitle("Tarama verilerini temizle")
            .setMessage("Geçmiş, önbellek, çerezler ve site verileri silinsin mi? (Yer imleri korunur)")
            .setPositiveButton("Temizle") { _, _ ->
                BrowserStore.clearHistory(this)
                webView.clearCache(true)
                webView.clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                WebStorage.getInstance().deleteAllData()
                Toast.makeText(this, "Temizlendi", Toast.LENGTH_SHORT).show()
                updateNavState()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
