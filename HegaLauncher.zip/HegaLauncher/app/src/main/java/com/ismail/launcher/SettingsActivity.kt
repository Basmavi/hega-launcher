package com.ismail.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var scope: String

    private val textColors = listOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFEB3B.toInt(),
        0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFF69F0AE.toInt()
    )
    private val dockColors = listOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF37474F.toInt(), 0xFF1565C0.toInt(),
        0xFF6A1B9A.toInt(), 0xFFC62828.toInt(), 0xFF2E7D32.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scope = intent.getStringExtra(EXTRA_SCOPE) ?: LauncherPrefs.HOME
        setContentView(R.layout.activity_settings)

        findViewById<TextView>(R.id.title).text =
            if (scope == LauncherPrefs.HOME) "Ana ekran ayarları" else "Menü (uygulama listesi) ayarları"

        if (scope == LauncherPrefs.HOME) setupHomeSection()
        else findViewById<View>(R.id.sectionHome).visibility = View.GONE

        findViewById<Button>(R.id.openMusicBtn).setOnClickListener {
            startActivity(Intent(this, MusicActivity::class.java))
        }

        setupShapeButtons()
        setupCommonSeekbars()
        setupLabelColors()

        findViewById<Button>(R.id.doneBtn).setOnClickListener { finish() }
    }

    // ---------- Ana ekrana özel ----------

    private fun setupHomeSection() {
        val clockSwitch = findViewById<Switch>(R.id.clockSwitch)
        clockSwitch.isChecked = LauncherPrefs.getShowClock(this)
        clockSwitch.setOnCheckedChangeListener { _, checked -> LauncherPrefs.setShowClock(this, checked) }

        bindSeek(
            findViewById(R.id.clockSizeLabel), findViewById(R.id.clockSizeSeek),
            20, 110, LauncherPrefs.getClockSizeSp(this), { "Saat boyutu ($it sp)" }
        ) { LauncherPrefs.setClockSizeSp(this, it) }

        bindSeek(
            findViewById(R.id.topGapLabel), findViewById(R.id.topGapSeek),
            0, 300, LauncherPrefs.getTopGapDp(this), { "Uygulamaların üst boşluğu ($it dp)" }
        ) { LauncherPrefs.setTopGapDp(this, it) }

        findViewById<Button>(R.id.resetLayoutBtn).setOnClickListener {
            LauncherPrefs.setClockPos(this, 0f, 0f)
            LauncherPrefs.resetWidgetLayout(this)
        }

        val dockRow = findViewById<LinearLayout>(R.id.dockColorRow)
        buildColorRow(dockRow, dockColors, LauncherPrefs.getDockColor(this)) { LauncherPrefs.setDockColor(this, it) }

        bindSeek(
            findViewById(R.id.dockAlphaLabel), findViewById(R.id.dockAlphaSeek),
            0, 100, LauncherPrefs.getDockAlpha(this), { "Dock opaklığı (%$it)" }
        ) { LauncherPrefs.setDockAlpha(this, it) }
    }

    // ---------- Ortak ----------

    private fun setupShapeButtons() {
        val current = findViewById<TextView>(R.id.shapeCurrent)
        fun refresh() {
            current.text = when (LauncherPrefs.getIconShape(this, scope)) {
                "circle" -> "Seçili: Yuvarlak"
                "squircle" -> "Seçili: Yumuşak kare"
                else -> "Seçili: Kare"
            }
        }
        refresh()
        findViewById<Button>(R.id.shapeSquare).setOnClickListener {
            LauncherPrefs.setIconShape(this, scope, "square"); refresh()
        }
        findViewById<Button>(R.id.shapeCircle).setOnClickListener {
            LauncherPrefs.setIconShape(this, scope, "circle"); refresh()
        }
        findViewById<Button>(R.id.shapeSquircle).setOnClickListener {
            LauncherPrefs.setIconShape(this, scope, "squircle"); refresh()
        }
    }

    private fun setupCommonSeekbars() {
        bindSeek(
            findViewById(R.id.iconSizeLabel), findViewById(R.id.iconSizeSeek),
            40, 88, LauncherPrefs.getIconSizeDp(this, scope), { "Simge boyutu ($it dp)" }
        ) { LauncherPrefs.setIconSizeDp(this, scope, it) }

        bindSeek(
            findViewById(R.id.labelSizeLabel), findViewById(R.id.labelSizeSeek),
            10, 22, LauncherPrefs.getLabelSizeSp(this, scope), { "Yazı boyutu ($it sp)" }
        ) { LauncherPrefs.setLabelSizeSp(this, scope, it) }

        bindSeek(
            findViewById(R.id.columnsLabel), findViewById(R.id.columnsSeek),
            3, 6, LauncherPrefs.getColumns(this, scope), { "Sütun sayısı ($it)" }
        ) { LauncherPrefs.setColumns(this, scope, it) }

        bindSeek(
            findViewById(R.id.rowsLabel), findViewById(R.id.rowsSeek),
            4, 8, LauncherPrefs.getRows(this, scope), { "Satır sayısı - sayfa başına ($it)" }
        ) { LauncherPrefs.setRows(this, scope, it) }
    }

    private fun setupLabelColors() {
        val row = findViewById<LinearLayout>(R.id.colorRow)
        buildColorRow(row, textColors, LauncherPrefs.getLabelColor(this, scope)) {
            LauncherPrefs.setLabelColor(this, scope, it)
        }
    }

    private fun bindSeek(
        labelView: TextView,
        seek: SeekBar,
        min: Int,
        max: Int,
        current: Int,
        format: (Int) -> String,
        onChange: (Int) -> Unit
    ) {
        seek.max = max - min
        seek.progress = (current - min).coerceIn(0, max - min)
        labelView.text = format(current.coerceIn(min, max))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = min + progress
                labelView.text = format(v)
                onChange(v)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun buildColorRow(row: LinearLayout, colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
        row.removeAllViews()
        row.gravity = Gravity.CENTER
        val density = resources.displayMetrics.density
        val sizePx = (36 * density).toInt()
        val margin = (5 * density).toInt()
        colors.forEach { c ->
            val swatch = View(this)
            val isSelected = (c == selected)
            swatch.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(if (isSelected) (4 * density).toInt() else 2, if (isSelected) Color.parseColor("#2196F3") else Color.GRAY)
            }
            val params = LinearLayout.LayoutParams(sizePx, sizePx)
            params.setMargins(margin, 0, margin, 0)
            swatch.layoutParams = params
            swatch.setOnClickListener {
                onPick(c)
                buildColorRow(row, colors, c, onPick)
            }
            row.addView(swatch)
        }
    }

    companion object {
        const val EXTRA_SCOPE = "scope"

        fun intent(context: Context, scope: String): Intent =
            Intent(context, SettingsActivity::class.java).putExtra(EXTRA_SCOPE, scope)
    }
}
