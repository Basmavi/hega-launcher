package com.ismail.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Hega Browser: yer imleri, geçmiş, arama motoru ve masaüstü modu ayarları. */
object BrowserStore {
    private const val NAME = "hega_browser_prefs"
    private const val KEY_BOOKMARKS = "bookmarks"
    private const val KEY_HISTORY = "history"
    private const val KEY_ENGINE = "engine"
    private const val KEY_DESKTOP = "desktop"
    private const val MAX_HISTORY = 200

    data class Entry(val title: String, val url: String, val time: Long = 0L)

    val ENGINE_IDS = listOf("google", "duckduckgo", "bing")
    val ENGINE_LABELS = listOf("Google", "DuckDuckGo", "Bing")

    private fun prefs(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // ---------- Arama motoru / masaüstü modu ----------

    fun getEngine(context: Context): String =
        prefs(context).getString(KEY_ENGINE, "google") ?: "google"

    fun setEngine(context: Context, id: String) {
        prefs(context).edit().putString(KEY_ENGINE, id).apply()
    }

    fun engineLabel(context: Context): String =
        ENGINE_LABELS.getOrNull(ENGINE_IDS.indexOf(getEngine(context))) ?: "Google"

    fun isDesktop(context: Context): Boolean = prefs(context).getBoolean(KEY_DESKTOP, false)

    fun setDesktop(context: Context, v: Boolean) {
        prefs(context).edit().putBoolean(KEY_DESKTOP, v).apply()
    }

    fun homeUrl(context: Context): String = when (getEngine(context)) {
        "duckduckgo" -> "https://duckduckgo.com"
        "bing" -> "https://www.bing.com"
        else -> "https://www.google.com"
    }

    private fun searchUrl(context: Context, query: String): String {
        val q = URLEncoder.encode(query, "UTF-8")
        return when (getEngine(context)) {
            "duckduckgo" -> "https://duckduckgo.com/?q=$q"
            "bing" -> "https://www.bing.com/search?q=$q"
            else -> "https://www.google.com/search?q=$q"
        }
    }

    /**
     * Adres çubuğuna yazılanı yüklenecek adrese çevirir:
     * tam http(s) adresi aynen, "ornek.com" gibi yazım https:// ile, diğer her şey arama olarak.
     * javascript:, file:, data: gibi şemalar asla doğrudan yüklenmez.
     */
    fun resolveInput(context: Context, raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return homeUrl(context)
        val lower = t.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) return t
        val hasSpace = t.contains(' ')
        val otherScheme = lower.contains("://") ||
            lower.startsWith("javascript:") || lower.startsWith("file:") ||
            lower.startsWith("data:") || lower.startsWith("content:") || lower.startsWith("about:")
        if (!hasSpace && !otherScheme && (t.contains('.') || lower.startsWith("localhost"))) {
            return "https://$t"
        }
        return searchUrl(context, t)
    }

    // ---------- Yer imleri ----------

    fun getBookmarks(context: Context): MutableList<Entry> = readList(context, KEY_BOOKMARKS)

    fun saveBookmarks(context: Context, list: List<Entry>) = writeList(context, KEY_BOOKMARKS, list)

    // ---------- Geçmiş ----------

    fun getHistory(context: Context): MutableList<Entry> = readList(context, KEY_HISTORY)

    fun addHistory(context: Context, title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:")) return
        val list = readList(context, KEY_HISTORY)
        if (list.isNotEmpty() && list[0].url == url) {
            list[0] = Entry(title, url, System.currentTimeMillis())
        } else {
            list.add(0, Entry(title, url, System.currentTimeMillis()))
        }
        while (list.size > MAX_HISTORY) list.removeAt(list.size - 1)
        writeList(context, KEY_HISTORY, list)
    }

    fun clearHistory(context: Context) {
        prefs(context).edit().remove(KEY_HISTORY).apply()
    }

    // ---------- Ortak ----------

    private fun readList(context: Context, key: String): MutableList<Entry> {
        val raw = prefs(context).getString(key, null) ?: return mutableListOf()
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t", ""), o.getString("u"), o.optLong("m", 0L)))
            }
        } catch (e: Exception) {
            // bozuk kayıt: boş liste
        }
        return out
    }

    private fun writeList(context: Context, key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            val o = JSONObject()
            o.put("t", e.title)
            o.put("u", e.url)
            o.put("m", e.time)
            arr.put(o)
        }
        prefs(context).edit().putString(key, arr.toString()).apply()
    }
}
