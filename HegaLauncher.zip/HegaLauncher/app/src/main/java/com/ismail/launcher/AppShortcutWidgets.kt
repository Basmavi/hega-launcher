package com.ismail.launcher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Hega uygulamalarının ana ekran widget'ları. Sistemin widget seçicisinde
 * (MIUI dahil herhangi bir launcher'da) ayrı ayrı görünür; her biri istenen
 * sayıda eklenebilir. Dokununca ilgili uygulama açılır.
 */
abstract class AppShortcutWidget : AppWidgetProvider() {

    protected abstract fun target(): Class<*>
    protected abstract fun iconRes(): Int

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_app)
            views.setImageViewResource(R.id.widgetIcon, iconRes())
            val intent = Intent(context, target()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pi)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}

class MusicWidget : AppShortcutWidget() {
    override fun target(): Class<*> = MusicActivity::class.java
    override fun iconRes(): Int = R.drawable.widget_music
}

class PhotosWidget : AppShortcutWidget() {
    override fun target(): Class<*> = PhotoActivity::class.java
    override fun iconRes(): Int = R.drawable.widget_photos
}

class VideoWidget : AppShortcutWidget() {
    override fun target(): Class<*> = VideoActivity::class.java
    override fun iconRes(): Int = R.drawable.widget_video
}
