package com.ismail.launcher

data class AppRef(val packageName: String, val activityName: String)

data class FolderInfo(var name: String, val apps: MutableList<AppRef>)

sealed class GridItem {
    data class AppItem(val app: AppInfo) : GridItem()
    data class FolderItem(val folder: FolderInfo, val icons: List<AppInfo>) : GridItem()
}
