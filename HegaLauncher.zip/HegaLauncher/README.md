# Hega Launcher

Tamamen yerel çalışan bir Android ana ekran launcher'ı. Gerçek uygulama simgesi,
Samsung/iOS tarzı sağ-sol kaydırmalı ana ekran, alt dock, klasörler, widget,
duvar kağıdı değiştirme ve ayrıntılı bir Ayarlar ekranı içeriyor.

## İçerik
- **Gerçek uygulama ikonu:** verdiğin logo, hafif yuvarlatılmış kare olarak işlendi.
- **Yatay kaydırmalı ana ekran:** uygulamalar sayfalara bölünür, parmakla sağa/sola
  kaydırarak gezilir. Altta sayfa noktaları (page indicator) gösterilir.
- **Dock:** ekranın en altında sabit duran, her sayfada aynı kalan kısayol barı
  (Samsung/iPhone'daki gibi). Bir uygulamaya uzun basıp "Dock'a ekle" diyerek
  ekleyebilirsin, en fazla 5 uygulama.
- **Klasörler:** bir uygulamaya uzun bas → "Klasöre taşı" → var olana ekle ya da
  yeni klasör aç. Klasöre dokununca içi açılır.
- **Widget:** boş alana uzun bas → "Widget ekle".
- **Duvar kağıdı değiştirme:** boş alana uzun bas → "Duvar kağıdını değiştir".
- **Ayarlar ekranı:** boş alana uzun bas → "Ayarlar". Buradan ayarlanabilenler:
  - Simge şekli: Kare (hafif yuvarlatılmış) / Yuvarlak (tam daire) / Yumuşak kare
  - Simge boyutu (40-88dp arası, kaydırmalı)
  - Yazı (etiket) boyutu (10-22sp arası)
  - Yazı rengi (6 renkten seç)
  - Sütun sayısı (3-6) ve sayfa başına satır sayısı (4-7) — bunlar aynı zamanda
    her sayfaya kaç uygulama sığacağını belirler
- Arama kutusu yazdıkça tüm uygulama ve klasörleri (sayfalardan bağımsız, tek
  liste halinde) filtreler.
- Arka planda cihazın kendi duvar kağıdı görünür.

## Kurulum (Android Studio)
1. Bu klasörü bilgisayarına indir/kopyala.
2. Android Studio'da **File → Open** ile bu klasörü aç.
3. Gradle wrapper dosyaları pakette yok; Android Studio senkronizasyon sırasında
   otomatik ekleyecek/soracaktır.
4. İlk senkronizasyon internet ister. Sonrasında uygulama tamamen çevrimdışı çalışır.
5. Telefonu USB ile bağla ya da emülatör kullan, **Run ▶** ile yükle.

## Varsayılan launcher yapma
**Ayarlar → Uygulamalar → Varsayılan uygulamalar → Ana ekran uygulaması** →
**Hega Launcher**.

## Notlar
- Widget ekleme, launcher varsayılan olarak seçilmemişse bir kere ekstra izin
  ekranı açabilir; bazı OEM'lerde (MIUI gibi) widget davranışı farklılık gösterebilir.
- Dock'taki uygulamalar ana ızgaradan silinmez, sadece alt barda bir kısayolu
  daha görünür — normal launcher davranışı budur.
- Sütun/satır sayısını değiştirmek, sayfa başına kapasiteyi değiştirir; mevcut
  uygulamalar otomatik olarak yeniden sayfalara dağıtılır.

## Sınırlamalar / geliştirilebilecekler
- Sayfalar arası uygulama sürükleyip taşıma yok; sıralama alfabetik.
- Klasör/dock içeriği menüden yönetiliyor, sürükle-bırak değil.
- Aynı anda yalnızca bir widget alanı var.
- İkon paketleri desteklenmiyor.

Bunlardan istediğin biri eklensin dersen üzerine koyabiliriz.
