package com.ismail.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var pageAdapter: PageAdapter
    private lateinit var dockContainer: LinearLayout
    private lateinit var indicatorContainer: LinearLayout

    private var allApps: List<AppInfo> = emptyList()
    private var currentGrid: List<GridItem> = emptyList()

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var dateView: TextView
    private lateinit var widgetContainer: FrameLayout

    private val appWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private lateinit var appWidgetHost: AppWidgetHost
    private var pendingProvider: AppWidgetProviderInfo? = null
    private var pendingWidgetId: Int = -1
    private var pendingConfigureId: Int = -1

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }

    private val bindWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val provider = pendingProvider
        val id = pendingWidgetId
        if (result.resultCode == RESULT_OK && provider != null && id != -1) {
            finishWidgetBind(id, provider)
        } else if (id != -1) {
            appWidgetHost.deleteAppWidgetId(id)
        }
        pendingProvider = null
        pendingWidgetId = -1
    }

    private val configureWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingConfigureId
        if (result.resultCode == RESULT_OK && id != -1) {
            addWidgetView(id)
        } else if (id != -1) {
            appWidgetHost.deleteAppWidgetId(id)
        }
        pendingConfigureId = -1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)

        clock = findViewById(R.id.clock)
        dateView = findViewById(R.id.date)
        widgetContainer = findViewById(R.id.widgetContainer)
        dockContainer = findViewById(R.id.dock)
        indicatorContainer = findViewById(R.id.pageIndicator)
        appWidgetHost = AppWidgetHost(this, WIDGET_HOST_ID)

        findViewById<View>(R.id.root).setOnLongClickListener { showBackgroundMenu(); true }
        findViewById<View>(R.id.appDrawerButton).setOnClickListener {
            startActivity(Intent(this, AppDrawerActivity::class.java))
        }

        pager = findViewById(R.id.pager)
        pageAdapter = PageAdapter(
            pages = emptyList(),
            columns = { LauncherPrefs.getColumns(this) },
            iconShape = { LauncherPrefs.getIconShape(this) },
            onAppTap = { app -> launchApp(app) },
            onAppLongPress = { app -> showAppOptions(app) },
            onFolderTap = { folderItem -> openFolder(folderItem) },
            onFolderLongPress = { folderItem -> showFolderOptions(folderItem) },
            onBackgroundLongPress = { showBackgroundMenu() }
        )
        pager.adapter = pageAdapter
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicatorActive(position)
            }
        })

        loadApps()
        restoreWidget()
    }

    override fun onStart() {
        super.onStart()
        appWidgetHost.startListening()
    }

    override fun onStop() {
        appWidgetHost.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Ana ekranda geri tuşu bir şey yapmamalı
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun updateClock() {
        val show = LauncherPrefs.getShowClock(this)
        clock.visibility = if (show) View.VISIBLE else View.GONE
        dateView.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        dateView.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr")).format(now)
    }

    // ---------- Uygulama listesi / sayfalar / dock ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        allApps = resolved.map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                activityName = it.activityInfo.name,
                icon = it.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        rebuildGrid()
        buildDock()
        updateClock()
    }

    /** Ana ekran, kullanıcının Uygulama Menüsü'nden tek tek eklediği öğelerden oluşur. */
    private fun rebuildGrid() {
        val homeItems = LauncherPrefs.getHomeItems(this)
        val folders = LauncherPrefs.getFolders(this)
        currentGrid = homeItems.mapNotNull { entry ->
            when (entry) {
                is HomeEntry.AppEntry -> allApps.find {
                    it.packageName == entry.ref.packageName && it.activityName == entry.ref.activityName
                }?.let { GridItem.AppItem(it) }
                is HomeEntry.FolderEntry -> folders.find { it.name == entry.folderName }?.let { f ->
                    val icons = f.apps.mapNotNull { ref ->
                        allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
                    }
                    GridItem.FolderItem(f, icons)
                }
            }
        }
        paginate()
    }

    private fun paginate() {
        val perPage = (LauncherPrefs.getColumns(this) * LauncherPrefs.getRows(this)).coerceAtLeast(1)
        val chunks = currentGrid.chunked(perPage)
        val pages = if (chunks.isEmpty()) listOf(emptyList()) else chunks
        pageAdapter.update(pages)
        buildIndicator(pages.size)
        if (pager.currentItem >= pages.size) pager.setCurrentItem(0, false)
    }

    private fun buildIndicator(count: Int) {
        indicatorContainer.removeAllViews()
        if (count <= 1) {
            indicatorContainer.visibility = View.GONE
            return
        }
        indicatorContainer.visibility = View.VISIBLE
        val size = dp(8)
        val margin = dp(4)
        for (i in 0 until count) {
            val dot = ImageView(this)
            dot.setImageResource(if (i == pager.currentItem) R.drawable.dot_active else R.drawable.dot_inactive)
            val params = LinearLayout.LayoutParams(size, size)
            params.setMargins(margin, 0, margin, 0)
            dot.layoutParams = params
            indicatorContainer.addView(dot)
        }
    }

    private fun updateIndicatorActive(active: Int) {
        for (i in 0 until indicatorContainer.childCount) {
            (indicatorContainer.getChildAt(i) as? ImageView)?.setImageResource(
                if (i == active) R.drawable.dot_active else R.drawable.dot_inactive
            )
        }
    }

    private fun buildDock() {
        dockContainer.removeAllViews()
        val dockRefs = LauncherPrefs.getDock(this)
        val apps = dockRefs.mapNotNull { ref ->
            allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
        }
        val iconPx = (LauncherPrefs.getIconSizeDp(this) * resources.displayMetrics.density).toInt()
        apps.forEach { app ->
            val cell = LayoutInflater.from(this).inflate(R.layout.item_app, dockContainer, false)
            val icon = cell.findViewById<ImageView>(R.id.icon)
            val label = cell.findViewById<TextView>(R.id.label)
            label.visibility = View.GONE
            val iconParams = icon.layoutParams
            iconParams.width = iconPx
            iconParams.height = iconPx
            icon.layoutParams = iconParams
            icon.setImageDrawable(IconShaper.apply(this, app.icon, LauncherPrefs.getIconShape(this)))
            cell.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            cell.setOnClickListener { launchApp(app) }
            cell.setOnLongClickListener { showAppOptions(app); true }
            dockContainer.addView(cell)
        }
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Uygulama açılamadıysa sessizce geç
        }
    }

    // ---------- Uygulama seçenekleri / klasörler / dock ----------

    private fun showAppOptions(app: AppInfo) {
        val inDock = LauncherPrefs.getDock(this).any { it.packageName == app.packageName && it.activityName == app.activityName }
        val options = arrayOf(
            "Uygulama bilgisi",
            "Ana ekrandan kaldır",
            if (inDock) "Dock'tan çıkar" else "Dock'a ekle",
            "Kaldır"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val uri = Uri.fromParts("package", app.packageName, null)
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) } catch (e: Exception) {}
                    }
                    1 -> {
                        val items = LauncherPrefs.getHomeItems(this)
                        items.removeAll { it is HomeEntry.AppEntry && it.ref.packageName == app.packageName && it.ref.activityName == app.activityName }
                        LauncherPrefs.saveHomeItems(this, items)
                        rebuildGrid()
                    }
                    2 -> toggleDock(app, inDock)
                    3 -> {
                        val uri = Uri.fromParts("package", app.packageName, null)
                        try { startActivity(Intent(Intent.ACTION_DELETE, uri)) } catch (e: Exception) {}
                    }
                }
            }
            .show()
    }

    private fun toggleDock(app: AppInfo, currentlyInDock: Boolean) {
        val dock = LauncherPrefs.getDock(this)
        if (currentlyInDock) {
            dock.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        } else {
            if (dock.size >= MAX_DOCK) dock.removeAt(0)
            dock.add(AppRef(app.packageName, app.activityName))
        }
        LauncherPrefs.saveDock(this, dock)
        buildDock()
    }

    private fun showFolderOptions(item: GridItem.FolderItem) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Ana ekrandan kaldır")) { _, _ ->
                val items = LauncherPrefs.getHomeItems(this)
                items.removeAll { it is HomeEntry.FolderEntry && it.folderName == item.folder.name }
                LauncherPrefs.saveHomeItems(this, items)
                rebuildGrid()
            }
            .show()
    }

    private fun openFolder(item: GridItem.FolderItem) {
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        item.icons.forEach { app ->
            val cellView = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            val icon = cellView.findViewById<ImageView>(R.id.icon)
            val label = cellView.findViewById<TextView>(R.id.label)
            icon.setImageDrawable(IconShaper.apply(this, app.icon, LauncherPrefs.getIconShape(this)))
            label.text = app.label
            label.setTextColor(Color.BLACK)
            cellView.layoutParams = GridLayout.LayoutParams().apply {
                width = dp(76)
                height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            cellView.setOnClickListener { launchApp(app) }
            cellView.setOnLongClickListener { removeFromFolder(item.folder, app); true }
            grid.addView(cellView)
        }
        scroll.addView(grid)
        AlertDialog.Builder(this)
            .setTitle(item.folder.name)
            .setView(scroll)
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun removeFromFolder(folder: FolderInfo, app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val target = folders.find { it.name == folder.name } ?: return
        target.apps.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        val cleaned = if (target.apps.isEmpty()) folders.filter { it !== target } else folders
        LauncherPrefs.saveFolders(this, cleaned)
        rebuildGrid()
    }

    // ---------- Arka plan menüsü: duvar kağıdı / ayarlar / widget ----------

    private fun showBackgroundMenu() {
        val hasWidget = LauncherPrefs.getWidget(this) != null
        val options = arrayOf(
            "Duvar kağıdını değiştir",
            "Ayarlar",
            if (hasWidget) "Widget'ı kaldır" else "Widget ekle"
        )
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> try { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) } catch (e: Exception) {}
                    1 -> startActivity(Intent(this, SettingsActivity::class.java))
                    2 -> if (hasWidget) removeWidget() else pickWidget()
                }
            }
            .show()
    }

    // ---------- Widget ----------

    private fun pickWidget() {
        val providers = appWidgetManager.installedProviders
        if (providers.isEmpty()) return
        val labels = providers.map { it.loadLabel(packageManager) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Widget seç")
            .setItems(labels) { _, which -> startWidgetBind(providers[which]) }
            .show()
    }

    private fun startWidgetBind(provider: AppWidgetProviderInfo) {
        val id = appWidgetHost.allocateAppWidgetId()
        val bound = appWidgetManager.bindAppWidgetIdIfAllowed(id, provider.provider)
        if (bound) {
            finishWidgetBind(id, provider)
        } else {
            pendingProvider = provider
            pendingWidgetId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
            }
            bindWidgetLauncher.launch(intent)
        }
    }

    private fun finishWidgetBind(id: Int, provider: AppWidgetProviderInfo) {
        if (provider.configure != null) {
            pendingConfigureId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = provider.configure
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            try {
                configureWidgetLauncher.launch(intent)
            } catch (e: Exception) {
                addWidgetView(id)
            }
        } else {
            addWidgetView(id)
        }
    }

    private fun addWidgetView(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id) ?: return
        widgetContainer.removeAllViews()
        val hostView = appWidgetHost.createView(this, id, info)
        hostView.setAppWidget(id, info)
        widgetContainer.addView(hostView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        widgetContainer.visibility = View.VISIBLE
        LauncherPrefs.saveWidget(this, id, info.provider.flattenToString())
    }

    private fun removeWidget() {
        LauncherPrefs.getWidget(this)?.let { appWidgetHost.deleteAppWidgetId(it.first) }
        LauncherPrefs.clearWidget(this)
        widgetContainer.removeAllViews()
        widgetContainer.visibility = View.GONE
    }

    private fun restoreWidget() {
        val saved = LauncherPrefs.getWidget(this) ?: return
        val info = appWidgetManager.getAppWidgetInfo(saved.first)
        if (info == null) {
            LauncherPrefs.clearWidget(this)
            return
        }
        widgetContainer.removeAllViews()
        val hostView = appWidgetHost.createView(this, saved.first, info)
        hostView.setAppWidget(saved.first, info)
        widgetContainer.addView(hostView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        widgetContainer.visibility = View.VISIBLE
    }

    companion object {
        private const val WIDGET_HOST_ID = 1024
        private const val MAX_DOCK = 5
    }
}
