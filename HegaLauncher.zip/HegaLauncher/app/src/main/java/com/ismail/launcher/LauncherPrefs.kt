package com.ismail.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object LauncherPrefs {
    const val HOME = "home"
    const val DRAWER = "drawer"

    private const val NAME = "hega_launcher_prefs"
    private const val KEY_SHAPE = "icon_shape"
    private const val KEY_ICON_SIZE = "icon_size_dp"
    private const val KEY_LABEL_SIZE = "label_size_sp"
    private const val KEY_LABEL_COLOR = "label_color"
    private const val KEY_COLUMNS = "columns"
    private const val KEY_ROWS = "rows"

    private const val KEY_FOLDERS = "folders"
    private const val KEY_WIDGET_ID = "widget_id"
    private const val KEY_WIDGET_PROVIDER = "widget_provider"
    private const val KEY_WIDGET_X = "widget_x_dp"
    private const val KEY_WIDGET_Y = "widget_y_dp"
    private const val KEY_WIDGET_W = "widget_w_dp"
    private const val KEY_WIDGET_H = "widget_h_dp"
    private const val KEY_DOCK = "dock"
    private const val KEY_DOCK_COLOR = "dock_color"
    private const val KEY_DOCK_ALPHA = "dock_alpha"
    private const val KEY_HOME = "home_items"
    private const val KEY_SHOW_CLOCK = "show_clock"
    private const val KEY_CLOCK_SIZE = "clock_size_sp"
    private const val KEY_CLOCK_X = "clock_x_dp"
    private const val KEY_CLOCK_Y = "clock_y_dp"
    private const val KEY_TOP_GAP = "top_gap_dp"

    private fun prefs(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    // ---------- Ana ekran / Menü için ayrı görünüm ayarları ----------
    // Eski (ayrışmamış) değerler varsa varsayılan olarak onlar kullanılır.

    fun getIconShape(context: Context, scope: String = HOME): String {
        val p = prefs(context)
        return p.getString("${scope}_$KEY_SHAPE", null) ?: p.getString(KEY_SHAPE, "square") ?: "square"
    }
    fun setIconShape(context: Context, scope: String, shape: String) {
        prefs(context).edit().putString("${scope}_$KEY_SHAPE", shape).apply()
    }

    fun getIconSizeDp(context: Context, scope: String = HOME): Int {
        val p = prefs(context)
        return p.getInt("${scope}_$KEY_ICON_SIZE", p.getInt(KEY_ICON_SIZE, 56))
    }
    fun setIconSizeDp(context: Context, scope: String, v: Int) {
        prefs(context).edit().putInt("${scope}_$KEY_ICON_SIZE", v).apply()
    }

    fun getLabelSizeSp(context: Context, scope: String = HOME): Int {
        val p = prefs(context)
        return p.getInt("${scope}_$KEY_LABEL_SIZE", p.getInt(KEY_LABEL_SIZE, 12))
    }
    fun setLabelSizeSp(context: Context, scope: String, v: Int) {
        prefs(context).edit().putInt("${scope}_$KEY_LABEL_SIZE", v).apply()
    }

    fun getLabelColor(context: Context, scope: String = HOME): Int {
        val p = prefs(context)
        return p.getInt("${scope}_$KEY_LABEL_COLOR", p.getInt(KEY_LABEL_COLOR, 0xFFFFFFFF.toInt()))
    }
    fun setLabelColor(context: Context, scope: String, v: Int) {
        prefs(context).edit().putInt("${scope}_$KEY_LABEL_COLOR", v).apply()
    }

    fun getColumns(context: Context, scope: String = HOME): Int {
        val p = prefs(context)
        return p.getInt("${scope}_$KEY_COLUMNS", p.getInt(KEY_COLUMNS, 4))
    }
    fun setColumns(context: Context, scope: String, v: Int) {
        prefs(context).edit().putInt("${scope}_$KEY_COLUMNS", v).apply()
    }

    fun getRows(context: Context, scope: String = HOME): Int {
        val p = prefs(context)
        return p.getInt("${scope}_$KEY_ROWS", p.getInt(KEY_ROWS, 5))
    }
    fun setRows(context: Context, scope: String, v: Int) {
        prefs(context).edit().putInt("${scope}_$KEY_ROWS", v).apply()
    }

    // ---------- Saat ----------
    fun getShowClock(context: Context): Boolean = prefs(context).getBoolean(KEY_SHOW_CLOCK, true)
    fun setShowClock(context: Context, v: Boolean) { prefs(context).edit().putBoolean(KEY_SHOW_CLOCK, v).apply() }

    fun getClockSizeSp(context: Context): Int = prefs(context).getInt(KEY_CLOCK_SIZE, 44)
    fun setClockSizeSp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_CLOCK_SIZE, v).apply() }

    fun getClockX(context: Context): Float = prefs(context).getFloat(KEY_CLOCK_X, 0f)
    fun getClockY(context: Context): Float = prefs(context).getFloat(KEY_CLOCK_Y, 0f)
    fun setClockPos(context: Context, x: Float, y: Float) {
        prefs(context).edit().putFloat(KEY_CLOCK_X, x).putFloat(KEY_CLOCK_Y, y).apply()
    }

    fun getTopGapDp(context: Context): Int = prefs(context).getInt(KEY_TOP_GAP, 100)
    fun setTopGapDp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_TOP_GAP, v).apply() }

    // ---------- Dock görünümü ----------
    fun getDockColor(context: Context): Int = prefs(context).getInt(KEY_DOCK_COLOR, 0xFF000000.toInt())
    fun setDockColor(context: Context, v: Int) { prefs(context).edit().putInt(KEY_DOCK_COLOR, v).apply() }

    /** 0..100 (yüzde opaklık) */
    fun getDockAlpha(context: Context): Int = prefs(context).getInt(KEY_DOCK_ALPHA, 20)
    fun setDockAlpha(context: Context, v: Int) { prefs(context).edit().putInt(KEY_DOCK_ALPHA, v).apply() }

    // ---------- Klasörler ----------
    fun getFolders(context: Context): MutableList<FolderInfo> {
        val raw = prefs(context).getString(KEY_FOLDERS, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val out = mutableListOf<FolderInfo>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val apps = mutableListOf<AppRef>()
            val appsArr = o.getJSONArray("apps")
            for (j in 0 until appsArr.length()) {
                val a = appsArr.getJSONObject(j)
                apps.add(AppRef(a.getString("pkg"), a.getString("cls")))
            }
            out.add(FolderInfo(o.getString("name"), apps))
        }
        return out
    }

    fun saveFolders(context: Context, folders: List<FolderInfo>) {
        val arr = JSONArray()
        folders.forEach { f ->
            val o = JSONObject()
            o.put("name", f.name)
            val appsArr = JSONArray()
            f.apps.forEach { a ->
                val ao = JSONObject()
                ao.put("pkg", a.packageName)
                ao.put("cls", a.activityName)
                appsArr.put(ao)
            }
            o.put("apps", appsArr)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_FOLDERS, arr.toString()).apply()
    }

    // ---------- Ana ekrana özel olarak yerleştirilenler ----------
    fun getHomeItems(context: Context): MutableList<HomeEntry> {
        val raw = prefs(context).getString(KEY_HOME, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val out = mutableListOf<HomeEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            when (o.getString("type")) {
                "app" -> out.add(HomeEntry.AppEntry(AppRef(o.getString("pkg"), o.getString("cls"))))
                "folder" -> out.add(HomeEntry.FolderEntry(o.getString("name")))
            }
        }
        return out
    }

    fun saveHomeItems(context: Context, items: List<HomeEntry>) {
        val arr = JSONArray()
        items.forEach { e ->
            val o = JSONObject()
            when (e) {
                is HomeEntry.AppEntry -> {
                    o.put("type", "app")
                    o.put("pkg", e.ref.packageName)
                    o.put("cls", e.ref.activityName)
                }
                is HomeEntry.FolderEntry -> {
                    o.put("type", "folder")
                    o.put("name", e.folderName)
                }
            }
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_HOME, arr.toString()).apply()
    }

    // ---------- Dock ----------
    fun getDock(context: Context): MutableList<AppRef> {
        val raw = prefs(context).getString(KEY_DOCK, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val out = mutableListOf<AppRef>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(AppRef(o.getString("pkg"), o.getString("cls")))
        }
        return out
    }

    fun saveDock(context: Context, dock: List<AppRef>) {
        val arr = JSONArray()
        dock.forEach { a ->
            val o = JSONObject()
            o.put("pkg", a.packageName)
            o.put("cls", a.activityName)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_DOCK, arr.toString()).apply()
    }

    // ---------- Widget ----------
    fun getWidget(context: Context): Pair<Int, String>? {
        val id = prefs(context).getInt(KEY_WIDGET_ID, -1)
        val provider = prefs(context).getString(KEY_WIDGET_PROVIDER, null)
        return if (id != -1 && provider != null) id to provider else null
    }

    fun saveWidget(context: Context, id: Int, provider: String) {
        prefs(context).edit().putInt(KEY_WIDGET_ID, id).putString(KEY_WIDGET_PROVIDER, provider).apply()
    }

    fun clearWidget(context: Context) {
        prefs(context).edit()
            .remove(KEY_WIDGET_ID).remove(KEY_WIDGET_PROVIDER)
            .remove(KEY_WIDGET_X).remove(KEY_WIDGET_Y)
            .remove(KEY_WIDGET_W).remove(KEY_WIDGET_H)
            .apply()
    }

    fun getWidgetX(context: Context): Float = prefs(context).getFloat(KEY_WIDGET_X, 0f)
    fun getWidgetY(context: Context): Float = prefs(context).getFloat(KEY_WIDGET_Y, 0f)
    fun setWidgetPos(context: Context, x: Float, y: Float) {
        prefs(context).edit().putFloat(KEY_WIDGET_X, x).putFloat(KEY_WIDGET_Y, y).apply()
    }

    /** 0 = otomatik boyut */
    fun getWidgetWidthDp(context: Context): Int = prefs(context).getInt(KEY_WIDGET_W, 0)
    fun getWidgetHeightDp(context: Context): Int = prefs(context).getInt(KEY_WIDGET_H, 0)
    fun setWidgetWidthDp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_WIDGET_W, v).apply() }
    fun setWidgetHeightDp(context: Context, v: Int) { prefs(context).edit().putInt(KEY_WIDGET_H, v).apply() }

    fun resetWidgetLayout(context: Context) {
        prefs(context).edit()
            .remove(KEY_WIDGET_X).remove(KEY_WIDGET_Y)
            .remove(KEY_WIDGET_W).remove(KEY_WIDGET_H)
            .apply()
    }
}
