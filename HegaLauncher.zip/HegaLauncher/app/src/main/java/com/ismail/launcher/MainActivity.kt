package com.ismail.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: AppAdapter
    private var allApps: List<AppInfo> = emptyList()
    private var currentGrid: List<GridItem> = emptyList()
    private var currentQuery: String = ""

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var dateView: TextView
    private lateinit var widgetContainer: FrameLayout

    private val appWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private lateinit var appWidgetHost: AppWidgetHost
    private var pendingProvider: AppWidgetProviderInfo? = null
    private var pendingWidgetId: Int = -1
    private var pendingConfigureId: Int = -1

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }

    private val bindWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val provider = pendingProvider
        val id = pendingWidgetId
        if (result.resultCode == RESULT_OK && provider != null && id != -1) {
            finishWidgetBind(id, provider)
        } else if (id != -1) {
            appWidgetHost.deleteAppWidgetId(id)
        }
        pendingProvider = null
        pendingWidgetId = -1
    }

    private val configureWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingConfigureId
        if (result.resultCode == RESULT_OK && id != -1) {
            addWidgetView(id)
        } else if (id != -1) {
            appWidgetHost.deleteAppWidgetId(id)
        }
        pendingConfigureId = -1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clock = findViewById(R.id.clock)
        dateView = findViewById(R.id.date)
        widgetContainer = findViewById(R.id.widgetContainer)
        appWidgetHost = AppWidgetHost(this, WIDGET_HOST_ID)

        findViewById<View>(R.id.root).setOnLongClickListener { showBackgroundMenu(); true }

        val grid = findViewById<RecyclerView>(R.id.appGrid)
        grid.layoutManager = GridLayoutManager(this, 4)
        adapter = AppAdapter(
            items = emptyList(),
            iconShape = { LauncherPrefs.getIconShape(this) },
            onAppTap = { app -> launchApp(app) },
            onAppLongPress = { app -> showAppOptions(app) },
            onFolderTap = { folderItem -> openFolder(folderItem) }
        )
        grid.adapter = adapter

        loadApps()
        restoreWidget()

        findViewById<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = filter(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onStart() {
        super.onStart()
        appWidgetHost.startListening()
    }

    override fun onStop() {
        appWidgetHost.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Ana ekranda geri tuşu bir şey yapmamalı
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        dateView.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr")).format(now)
    }

    // ---------- Uygulama listesi / ızgara ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        allApps = resolved.map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                activityName = it.activityInfo.name,
                icon = it.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        rebuildGrid()
    }

    private fun rebuildGrid() {
        val folders = LauncherPrefs.getFolders(this)
        val usedRefs = folders.flatMap { it.apps }.map { it.packageName to it.activityName }.toSet()
        val loneApps = allApps.filter { (it.packageName to it.activityName) !in usedRefs }

        val folderItems = folders.map { f ->
            val icons = f.apps.mapNotNull { ref ->
                allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
            }
            GridItem.FolderItem(f, icons)
        }
        val appItems = loneApps.map { GridItem.AppItem(it) }

        currentGrid = (folderItems + appItems).sortedBy {
            when (it) {
                is GridItem.FolderItem -> it.folder.name.lowercase(Locale.getDefault())
                is GridItem.AppItem -> it.app.label.lowercase(Locale.getDefault())
            }
        }
        adapter.update(applyFilter(currentGrid, currentQuery))
    }

    private fun applyFilter(items: List<GridItem>, q: String): List<GridItem> {
        if (q.isBlank()) return items
        val lq = q.lowercase(Locale.getDefault())
        return items.filter {
            when (it) {
                is GridItem.AppItem -> it.app.label.lowercase(Locale.getDefault()).contains(lq)
                is GridItem.FolderItem -> it.folder.name.lowercase(Locale.getDefault()).contains(lq) ||
                    it.icons.any { a -> a.label.lowercase(Locale.getDefault()).contains(lq) }
            }
        }
    }

    private fun filter(q: String) {
        currentQuery = q
        adapter.update(applyFilter(currentGrid, q))
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Uygulama açılamadıysa sessizce geç
        }
    }

    // ---------- Uygulama seçenekleri / klasörler ----------

    private fun showAppOptions(app: AppInfo) {
        val options = arrayOf("Uygulama bilgisi", "Klasöre taşı", "Kaldır")
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val uri = Uri.fromParts("package", app.packageName, null)
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) } catch (e: Exception) {}
                    }
                    1 -> moveToFolder(app)
                    2 -> {
                        val uri = Uri.fromParts("package", app.packageName, null)
                        try { startActivity(Intent(Intent.ACTION_DELETE, uri)) } catch (e: Exception) {}
                    }
                }
            }
            .show()
    }

    private fun moveToFolder(app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val names = (folders.map { it.name } + "+ Yeni klasör").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Klasöre ekle")
            .setItems(names) { _, which ->
                if (which == folders.size) {
                    promptNewFolderName { name ->
                        val updated = folders + FolderInfo(name, mutableListOf(AppRef(app.packageName, app.activityName)))
                        LauncherPrefs.saveFolders(this, updated)
                        rebuildGrid()
                    }
                } else {
                    folders[which].apps.add(AppRef(app.packageName, app.activityName))
                    LauncherPrefs.saveFolders(this, folders)
                    rebuildGrid()
                }
            }
            .show()
    }

    private fun promptNewFolderName(onDone: (String) -> Unit) {
        val input = EditText(this)
        input.hint = "Klasör adı"
        AlertDialog.Builder(this)
            .setTitle("Yeni klasör")
            .setView(input)
            .setPositiveButton("Oluştur") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) onDone(name)
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun openFolder(item: GridItem.FolderItem) {
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        item.icons.forEach { app ->
            val cellView = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            val icon = cellView.findViewById<ImageView>(R.id.icon)
            val label = cellView.findViewById<TextView>(R.id.label)
            icon.setImageDrawable(IconShaper.apply(this, app.icon, LauncherPrefs.getIconShape(this)))
            label.text = app.label
            label.setTextColor(Color.BLACK)
            cellView.layoutParams = GridLayout.LayoutParams().apply {
                width = dp(76)
                height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            cellView.setOnClickListener { launchApp(app) }
            cellView.setOnLongClickListener { removeFromFolder(item.folder, app); true }
            grid.addView(cellView)
        }
        scroll.addView(grid)
        AlertDialog.Builder(this)
            .setTitle(item.folder.name)
            .setView(scroll)
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun removeFromFolder(folder: FolderInfo, app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val target = folders.find { it.name == folder.name } ?: return
        target.apps.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        val cleaned = if (target.apps.isEmpty()) folders.filter { it !== target } else folders
        LauncherPrefs.saveFolders(this, cleaned)
        rebuildGrid()
    }

    // ---------- Arka plan menüsü: duvar kağıdı / simge şekli / widget ----------

    private fun showBackgroundMenu() {
        val hasWidget = LauncherPrefs.getWidget(this) != null
        val options = arrayOf(
            "Duvar kağıdını değiştir",
            "Simge şekli",
            if (hasWidget) "Widget'ı kaldır" else "Widget ekle"
        )
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> try { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) } catch (e: Exception) {}
                    1 -> pickIconShape()
                    2 -> if (hasWidget) removeWidget() else pickWidget()
                }
            }
            .show()
    }

    private fun pickIconShape() {
        val labels = arrayOf("Kare", "Yuvarlak", "Yumuşak kare")
        val values = arrayOf("square", "circle", "squircle")
        AlertDialog.Builder(this)
            .setTitle("Simge şekli")
            .setItems(labels) { _, which ->
                LauncherPrefs.setIconShape(this, values[which])
                rebuildGrid()
            }
            .show()
    }

    // ---------- Widget ----------

    private fun pickWidget() {
        val providers = appWidgetManager.installedProviders
        if (providers.isEmpty()) return
        val labels = providers.map { it.loadLabel(packageManager) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Widget seç")
            .setItems(labels) { _, which -> startWidgetBind(providers[which]) }
            .show()
    }

    private fun startWidgetBind(provider: AppWidgetProviderInfo) {
        val id = appWidgetHost.allocateAppWidgetId()
        val bound = appWidgetManager.bindAppWidgetIdIfAllowed(id, provider.provider)
        if (bound) {
            finishWidgetBind(id, provider)
        } else {
            pendingProvider = provider
            pendingWidgetId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
            }
            bindWidgetLauncher.launch(intent)
        }
    }

    private fun finishWidgetBind(id: Int, provider: AppWidgetProviderInfo) {
        if (provider.configure != null) {
            pendingConfigureId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = provider.configure
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            try {
                configureWidgetLauncher.launch(intent)
            } catch (e: Exception) {
                addWidgetView(id)
            }
        } else {
            addWidgetView(id)
        }
    }

    private fun addWidgetView(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id) ?: return
        widgetContainer.removeAllViews()
        val hostView = appWidgetHost.createView(this, id, info)
        hostView.setAppWidget(id, info)
        widgetContainer.addView(hostView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        widgetContainer.visibility = View.VISIBLE
        LauncherPrefs.saveWidget(this, id, info.provider.flattenToString())
    }

    private fun removeWidget() {
        LauncherPrefs.getWidget(this)?.let { appWidgetHost.deleteAppWidgetId(it.first) }
        LauncherPrefs.clearWidget(this)
        widgetContainer.removeAllViews()
        widgetContainer.visibility = View.GONE
    }

    private fun restoreWidget() {
        val saved = LauncherPrefs.getWidget(this) ?: return
        val info = appWidgetManager.getAppWidgetInfo(saved.first)
        if (info == null) {
            LauncherPrefs.clearWidget(this)
            return
        }
        widgetContainer.removeAllViews()
        val hostView = appWidgetHost.createView(this, saved.first, info)
        hostView.setAppWidget(saved.first, info)
        widgetContainer.addView(hostView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        widgetContainer.visibility = View.VISIBLE
    }

    companion object {
        private const val WIDGET_HOST_ID = 1024
    }
}
