package com.ismail.launcher

/** Hega Launcher ana ekranındaki bir widget'ın kaydı. wDp/hDp = 0 ise otomatik boyut. */
data class WidgetState(
    val id: Int,
    val provider: String,
    var xDp: Float,
    var yDp: Float,
    var wDp: Int,
    var hDp: Int
)
