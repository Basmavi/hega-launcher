package com.ismail.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private class MenuEntry(val label: String, val action: () -> Unit)

    private class SliderSpec(
        val label: String,
        val min: Int,
        val max: Int,
        val value: Int,
        val onChange: (Int) -> Unit
    )

    private lateinit var pager: ViewPager2
    private lateinit var pageAdapter: PageAdapter
    private lateinit var dockBar: LinearLayout
    private lateinit var dockContainer: LinearLayout
    private lateinit var indicatorContainer: LinearLayout
    private lateinit var clockBox: DragLayout
    private lateinit var clock: TextView
    private lateinit var dateView: TextView
    private lateinit var headerLayer: FrameLayout
    private val widgetBoxes = mutableMapOf<Int, DragLayout>()
    private var createdTheme: String = ""

    private var allApps: List<AppInfo> = emptyList()
    private var currentGrid: List<GridItem> = emptyList()
    private var pendingMove: GridItem? = null
    private var pendingDockMove: AppInfo? = null

    private val handler = Handler(Looper.getMainLooper())

    private val appWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private lateinit var appWidgetHost: AppWidgetHost
    private var pendingProvider: AppWidgetProviderInfo? = null
    private var pendingWidgetId: Int = -1
    private var pendingConfigureId: Int = -1

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }

    private val bindWidgetLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val provider = pendingProvider
        val id = pendingWidgetId
        pendingProvider = null
        pendingWidgetId = -1
        if (result.resultCode == RESULT_OK && provider != null && id != -1) {
            onWidgetBound(id, provider)
        } else if (id != -1) {
            appWidgetHost.deleteAppWidgetId(id)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(ThemeHelper.launcherTheme(this))
        createdTheme = LauncherPrefs.getTheme(this)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(0, bars.top + dp(8), 0, bars.bottom)
            insets
        }

        clockBox = findViewById(R.id.clockBox)
        clock = findViewById(R.id.clock)
        dateView = findViewById(R.id.date)
        headerLayer = findViewById(R.id.headerLayer)
        dockBar = findViewById(R.id.dockBar)
        dockContainer = findViewById(R.id.dock)
        indicatorContainer = findViewById(R.id.pageIndicator)
        appWidgetHost = AppWidgetHost(this, WIDGET_HOST_ID)

        root.setOnLongClickListener { showBackgroundMenu(); true }
        clockBox.setOnLongClickListener { showClockMenu(); true }
        findViewById<View>(R.id.appDrawerButton).setOnClickListener {
            startActivity(Intent(this, AppDrawerActivity::class.java))
        }

        pager = findViewById(R.id.pager)
        pageAdapter = PageAdapter(
            pages = emptyList(),
            scope = LauncherPrefs.HOME,
            onAppTap = { app -> handleGridTap(GridItem.AppItem(app)) { launchApp(app) } },
            onAppLongPress = { app -> showAppOptions(app) },
            onFolderTap = { folderItem -> handleGridTap(folderItem) { openFolder(folderItem) } },
            onFolderLongPress = { folderItem -> showFolderOptions(folderItem) },
            onBackgroundLongPress = { showBackgroundMenu() }
        )
        pager.adapter = pageAdapter
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicatorActive(position)
            }
        })

        loadApps()
        restoreWidgets()
        applyLayoutPrefs()
    }

    override fun onStart() {
        super.onStart()
        appWidgetHost.startListening()
    }

    override fun onStop() {
        appWidgetHost.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (createdTheme != LauncherPrefs.getTheme(this)) {
            recreate()
            return
        }
        loadApps()
        applyLayoutPrefs()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Ana ekranda geri tuşu bir şey yapmamalı
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CONFIGURE) {
            val id = pendingConfigureId
            pendingConfigureId = -1
            if (id == -1) return
            if (resultCode == RESULT_OK) finalizeWidget(id) else appWidgetHost.deleteAppWidgetId(id)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------- Genel menü / kaydırıcı yardımcıları ----------

    private fun showMenu(title: String?, entries: List<MenuEntry>) {
        val builder = AlertDialog.Builder(this)
        if (title != null) builder.setTitle(title)
        builder.setItems(entries.map { it.label }.toTypedArray()) { _, which -> entries[which].action() }
        builder.show()
    }

    private fun showSliders(title: String, specs: List<SliderSpec>) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))
        specs.forEach { s ->
            val tv = TextView(this)
            tv.text = "${s.label}: ${s.value}"
            val sb = SeekBar(this)
            sb.max = s.max - s.min
            sb.progress = (s.value - s.min).coerceIn(0, s.max - s.min)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = s.min + progress
                    tv.text = "${s.label}: $v"
                    s.onChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            box.addView(tv)
            box.addView(sb)
        }
        AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("Tamam", null).show()
    }

    private fun startDrag(box: DragLayout, save: (Float, Float) -> Unit) {
        Toast.makeText(this, "Parmağınla sürükle, bırakınca konum kaydedilir", Toast.LENGTH_SHORT).show()
        val density = resources.displayMetrics.density
        box.onDragEnd = { tx, ty -> save(tx / density, ty / density) }
        box.dragEnabled = true
    }

    // ---------- Görünüm ayarlarını uygula ----------

    private fun applyLayoutPrefs() {
        val density = resources.displayMetrics.density

        val pagerParams = pager.layoutParams as LinearLayout.LayoutParams
        pagerParams.topMargin = dp(LauncherPrefs.getTopGapDp(this))
        pager.layoutParams = pagerParams

        clockBox.visibility = if (LauncherPrefs.getShowClock(this)) View.VISIBLE else View.GONE
        val sizeSp = LauncherPrefs.getClockSizeSp(this).toFloat()
        clock.textSize = sizeSp
        dateView.textSize = maxOf(10f, sizeSp * 0.34f)
        clockBox.translationX = LauncherPrefs.getClockX(this) * density
        clockBox.translationY = LauncherPrefs.getClockY(this) * density

        applyWidgetLayouts()

        applyDockStyle()
        updateClock()
    }

    private fun applyDockStyle() {
        val rgb = LauncherPrefs.getDockColor(this) and 0xFFFFFF
        val alpha = (LauncherPrefs.getDockAlpha(this) * 255 / 100).coerceIn(0, 255)
        val bg = GradientDrawable()
        bg.cornerRadius = 28f * resources.displayMetrics.density
        bg.setColor((alpha shl 24) or rgb)
        dockBar.background = bg
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        dateView.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr")).format(now)
    }

    // ---------- Uygulama listesi / sayfalar / dock ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        allApps = resolved.map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                activityName = it.activityInfo.name,
                icon = it.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        rebuildGrid()
        buildDock()
    }

    /** Ana ekran, kullanıcının Uygulama Menüsü'nden tek tek eklediği öğelerden oluşur. */
    private fun rebuildGrid() {
        val homeItems = LauncherPrefs.getHomeItems(this)
        val folders = LauncherPrefs.getFolders(this)
        currentGrid = homeItems.mapNotNull { entry ->
            when (entry) {
                is HomeEntry.AppEntry -> allApps.find {
                    it.packageName == entry.ref.packageName && it.activityName == entry.ref.activityName
                }?.let { GridItem.AppItem(it) }
                is HomeEntry.FolderEntry -> folders.find { it.name == entry.folderName }?.let { f ->
                    val icons = f.apps.mapNotNull { ref ->
                        allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
                    }
                    GridItem.FolderItem(f, icons)
                }
            }
        }
        paginate()
    }

    private fun paginate() {
        val perPage = (LauncherPrefs.getColumns(this, LauncherPrefs.HOME) *
            LauncherPrefs.getRows(this, LauncherPrefs.HOME)).coerceAtLeast(1)
        val chunks = currentGrid.chunked(perPage)
        val pages = if (chunks.isEmpty()) listOf(emptyList()) else chunks
        pageAdapter.update(pages)
        buildIndicator(pages.size)
        if (pager.currentItem >= pages.size) pager.setCurrentItem(0, false)
    }

    private fun buildIndicator(count: Int) {
        indicatorContainer.removeAllViews()
        if (count <= 1) {
            indicatorContainer.visibility = View.GONE
            return
        }
        indicatorContainer.visibility = View.VISIBLE
        val size = dp(8)
        val margin = dp(4)
        for (i in 0 until count) {
            val dot = ImageView(this)
            dot.setImageResource(if (i == pager.currentItem) R.drawable.dot_active else R.drawable.dot_inactive)
            val params = LinearLayout.LayoutParams(size, size)
            params.setMargins(margin, 0, margin, 0)
            dot.layoutParams = params
            indicatorContainer.addView(dot)
        }
    }

    private fun updateIndicatorActive(active: Int) {
        for (i in 0 until indicatorContainer.childCount) {
            (indicatorContainer.getChildAt(i) as? ImageView)?.setImageResource(
                if (i == active) R.drawable.dot_active else R.drawable.dot_inactive
            )
        }
    }

    private fun buildDock() {
        dockContainer.removeAllViews()
        val apps = LauncherPrefs.getDock(this).mapNotNull { ref ->
            allApps.find { it.packageName == ref.packageName && it.activityName == ref.activityName }
        }
        val iconPx = (LauncherPrefs.getIconSizeDp(this, LauncherPrefs.HOME) * resources.displayMetrics.density).toInt()
        val shape = LauncherPrefs.getIconShape(this, LauncherPrefs.HOME)
        apps.forEach { app ->
            val cell = LayoutInflater.from(this).inflate(R.layout.item_app, dockContainer, false)
            val icon = cell.findViewById<ImageView>(R.id.icon)
            val label = cell.findViewById<TextView>(R.id.label)
            label.visibility = View.GONE
            val iconParams = icon.layoutParams
            iconParams.width = iconPx
            iconParams.height = iconPx
            icon.layoutParams = iconParams
            icon.setImageDrawable(IconShaper.apply(this, app.icon, shape, iconPx))
            cell.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            cell.setOnClickListener {
                val pending = pendingDockMove
                if (pending != null) {
                    pendingDockMove = null
                    swapDock(pending, app)
                } else {
                    launchApp(app)
                }
            }
            cell.setOnLongClickListener { showAppOptions(app, inDock = true); true }
            dockContainer.addView(cell)
        }
    }

    /** "Yerini değiştir" seçiliyken bir sonraki dokunuş, o öğeyle yer değiştirir. */
    private fun handleGridTap(tapped: GridItem, normalAction: () -> Unit) {
        val pending = pendingMove
        if (pending != null) {
            pendingMove = null
            swapItems(pending, tapped)
        } else {
            normalAction()
        }
    }

    private fun homeKeyOf(item: GridItem): HomeEntry? {
        val items = LauncherPrefs.getHomeItems(this)
        return when (item) {
            is GridItem.AppItem -> items.find {
                it is HomeEntry.AppEntry && it.ref.packageName == item.app.packageName && it.ref.activityName == item.app.activityName
            }
            is GridItem.FolderItem -> items.find { it is HomeEntry.FolderEntry && it.folderName == item.folder.name }
        }
    }

    private fun swapItems(a: GridItem, b: GridItem) {
        val items = LauncherPrefs.getHomeItems(this)
        val ka = homeKeyOf(a)
        val kb = homeKeyOf(b)
        val ia = items.indexOf(ka)
        val ib = items.indexOf(kb)
        if (ia == -1 || ib == -1 || ia == ib) return
        val tmp = items[ia]
        items[ia] = items[ib]
        items[ib] = tmp
        LauncherPrefs.saveHomeItems(this, items)
        rebuildGrid()
        Toast.makeText(this, "Yerleri değiştirildi", Toast.LENGTH_SHORT).show()
    }

    private fun swapDock(a: AppInfo, b: AppInfo) {
        val dock = LauncherPrefs.getDock(this)
        val ia = dock.indexOfFirst { it.packageName == a.packageName && it.activityName == a.activityName }
        val ib = dock.indexOfFirst { it.packageName == b.packageName && it.activityName == b.activityName }
        if (ia == -1 || ib == -1 || ia == ib) return
        val tmp = dock[ia]
        dock[ia] = dock[ib]
        dock[ib] = tmp
        LauncherPrefs.saveDock(this, dock)
        buildDock()
        Toast.makeText(this, "Yerleri değiştirildi", Toast.LENGTH_SHORT).show()
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Uygulama açılamadıysa sessizce geç
        }
    }

    // ---------- Uygulama seçenekleri / klasörler / dock ----------

    private fun isInDock(app: AppInfo): Boolean =
        LauncherPrefs.getDock(this).any { it.packageName == app.packageName && it.activityName == app.activityName }

    private fun showAppOptions(app: AppInfo, inDock: Boolean = false) {
        val inDockNow = isInDock(app)
        val entries = mutableListOf(
            MenuEntry("Uygulama bilgisi") { openAppInfo(app) },
            MenuEntry("Yerini değiştir") {
                if (inDock) {
                    pendingDockMove = app
                    Toast.makeText(this, "Şimdi dock'ta yer değiştirmek istediğin uygulamaya dokun", Toast.LENGTH_SHORT).show()
                } else {
                    pendingMove = GridItem.AppItem(app)
                    Toast.makeText(this, "Şimdi yer değiştirmek istediğin uygulama/klasöre dokun", Toast.LENGTH_SHORT).show()
                }
            },
            MenuEntry(if (inDockNow) "Dock'tan çıkar" else "Dock'a ekle") { toggleDock(app, inDockNow) }
        )
        if (!inDock) entries.add(MenuEntry("Ana ekrandan kaldır") { removeFromHome(app) })
        entries.add(MenuEntry("Kaldır") { uninstall(app) })
        showMenu(app.label, entries)
    }

    private fun openAppInfo(app: AppInfo) {
        val uri = Uri.fromParts("package", app.packageName, null)
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) } catch (e: Exception) {}
    }

    private fun uninstall(app: AppInfo) {
        val uri = Uri.fromParts("package", app.packageName, null)
        try { startActivity(Intent(Intent.ACTION_DELETE, uri)) } catch (e: Exception) {}
    }

    private fun removeFromHome(app: AppInfo) {
        val items = LauncherPrefs.getHomeItems(this)
        items.removeAll { it is HomeEntry.AppEntry && it.ref.packageName == app.packageName && it.ref.activityName == app.activityName }
        LauncherPrefs.saveHomeItems(this, items)
        rebuildGrid()
    }

    private fun toggleDock(app: AppInfo, currentlyInDock: Boolean) {
        val dock = LauncherPrefs.getDock(this)
        if (currentlyInDock) {
            dock.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        } else {
            if (dock.size >= MAX_DOCK) dock.removeAt(0)
            dock.add(AppRef(app.packageName, app.activityName))
        }
        LauncherPrefs.saveDock(this, dock)
        buildDock()
    }

    private fun showFolderOptions(item: GridItem.FolderItem) {
        showMenu(
            item.folder.name,
            listOf(
                MenuEntry("Yerini değiştir") {
                    pendingMove = item
                    Toast.makeText(this, "Şimdi yer değiştirmek istediğin uygulama/klasöre dokun", Toast.LENGTH_SHORT).show()
                },
                MenuEntry("Ana ekrandan kaldır") {
                    val items = LauncherPrefs.getHomeItems(this)
                    items.removeAll { it is HomeEntry.FolderEntry && it.folderName == item.folder.name }
                    LauncherPrefs.saveHomeItems(this, items)
                    rebuildGrid()
                }
            )
        )
    }

    private fun openFolder(item: GridItem.FolderItem) {
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val shape = LauncherPrefs.getIconShape(this, LauncherPrefs.HOME)
        item.icons.forEach { app ->
            val cellView = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            val icon = cellView.findViewById<ImageView>(R.id.icon)
            val label = cellView.findViewById<TextView>(R.id.label)
            icon.setImageDrawable(IconShaper.apply(this, app.icon, shape, dp(56)))
            label.text = app.label
            label.setTextColor(ThemeHelper.dialogTextColor(this))
            cellView.layoutParams = GridLayout.LayoutParams().apply {
                width = dp(76)
                height = GridLayout.LayoutParams.WRAP_CONTENT
            }
            cellView.setOnClickListener { launchApp(app) }
            cellView.setOnLongClickListener { removeFromFolder(item.folder, app); true }
            grid.addView(cellView)
        }
        scroll.addView(grid)
        AlertDialog.Builder(this)
            .setTitle(item.folder.name)
            .setView(scroll)
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun removeFromFolder(folder: FolderInfo, app: AppInfo) {
        val folders = LauncherPrefs.getFolders(this)
        val target = folders.find { it.name == folder.name } ?: return
        target.apps.removeAll { it.packageName == app.packageName && it.activityName == app.activityName }
        val cleaned = if (target.apps.isEmpty()) folders.filter { it !== target } else folders
        LauncherPrefs.saveFolders(this, cleaned)
        rebuildGrid()
    }

    // ---------- Arka plan menüsü ----------

    private fun showBackgroundMenu() {
        val showClock = LauncherPrefs.getShowClock(this)
        val entries = mutableListOf(
            MenuEntry("Duvar kağıdını değiştir") {
                try { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) } catch (e: Exception) {}
            },
            MenuEntry("Ana ekran ayarları") {
                startActivity(SettingsActivity.intent(this, LauncherPrefs.HOME))
            },
            MenuEntry(if (showClock) "Saati gizle" else "Saati göster") {
                LauncherPrefs.setShowClock(this, !showClock)
                applyLayoutPrefs()
            }
        )
        if (showClock) entries.add(MenuEntry("Saati düzenle (taşı / boyut)") { showClockMenu() })
        entries.add(MenuEntry("Widget ekle") { pickWidget() })
        if (LauncherPrefs.getWidgets(this).isNotEmpty()) {
            entries.add(MenuEntry("Widget konum/boyutlarını sıfırla") {
                LauncherPrefs.resetWidgetLayout(this)
                applyWidgetLayouts()
            })
        }
        showMenu(null, entries)
    }

    // ---------- Saat düzenleme ----------

    private fun showClockMenu() {
        showMenu(
            "Saat",
            listOf(
                MenuEntry("Sürükleyerek taşı") {
                    startDrag(clockBox) { x, y -> LauncherPrefs.setClockPos(this, x, y) }
                },
                MenuEntry("Boyutu ayarla") {
                    showSliders(
                        "Saat boyutu",
                        listOf(
                            SliderSpec("Boyut (sp)", 20, 110, LauncherPrefs.getClockSizeSp(this)) { v ->
                                LauncherPrefs.setClockSizeSp(this, v)
                                applyLayoutPrefs()
                            }
                        )
                    )
                },
                MenuEntry("Konumu sıfırla") {
                    LauncherPrefs.setClockPos(this, 0f, 0f)
                    applyLayoutPrefs()
                },
                MenuEntry("Saati gizle") {
                    LauncherPrefs.setShowClock(this, false)
                    applyLayoutPrefs()
                }
            )
        )
    }

    // ---------- Widget'lar (sınırsız sayıda) ----------

    private fun widgetState(id: Int): WidgetState? = LauncherPrefs.getWidgets(this).find { it.id == id }

    private fun updateWidgetState(id: Int, change: (WidgetState) -> Unit) {
        val list = LauncherPrefs.getWidgets(this)
        val w = list.find { it.id == id } ?: return
        change(w)
        LauncherPrefs.saveWidgets(this, list)
    }

    private fun showWidgetMenu(id: Int) {
        showMenu(
            "Widget",
            listOf(
                MenuEntry("Sürükleyerek taşı") {
                    widgetBoxes[id]?.let { box ->
                        startDrag(box) { x, y -> updateWidgetState(id) { it.xDp = x; it.yDp = y } }
                    }
                },
                MenuEntry("Boyutu ayarla") { showWidgetSizeDialog(id) },
                MenuEntry("Konum ve boyutu sıfırla") {
                    updateWidgetState(id) { it.xDp = 0f; it.yDp = 0f; it.wDp = 0; it.hDp = 0 }
                    applyWidgetLayouts()
                },
                MenuEntry("Widget'ı kaldır") { removeWidget(id) }
            )
        )
    }

    private fun showWidgetSizeDialog(id: Int) {
        val st = widgetState(id) ?: return
        val density = resources.displayMetrics.density
        val screenWdp = (resources.displayMetrics.widthPixels / density).toInt()
        val host = widgetBoxes[id]?.getChildAt(0) as? AppWidgetHostView
        val lp = host?.layoutParams
        val autoW = ((lp?.width ?: 0) / density).toInt()
        val autoH = ((lp?.height ?: 0) / density).toInt()
        val maxW = maxOf(screenWdp, 120)
        val curW = if (st.wDp > 0) st.wDp else if (autoW > 0) autoW else screenWdp - 32
        val curH = if (st.hDp > 0) st.hDp else if (autoH > 0) autoH else 56
        showSliders(
            "Widget boyutu",
            listOf(
                SliderSpec("Genişlik (dp)", 40, maxW, curW.coerceIn(40, maxW)) { v ->
                    updateWidgetState(id) { it.wDp = v }
                    applyWidgetLayouts()
                },
                SliderSpec("Yükseklik (dp)", 40, 600, curH.coerceIn(40, 600)) { v ->
                    updateWidgetState(id) { it.hDp = v }
                    applyWidgetLayouts()
                }
            )
        )
    }

    /** Kayıtlı konum ve boyutları tüm widget'lara uygular. */
    private fun applyWidgetLayouts() {
        val density = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        for (st in LauncherPrefs.getWidgets(this)) {
            val box = widgetBoxes[st.id] ?: continue
            box.translationX = st.xDp * density
            box.translationY = st.yDp * density
            val host = box.getChildAt(0) as? AppWidgetHostView ?: continue
            val info = host.appWidgetInfo ?: continue
            // Varsayılan boyut: Android 12+ widget'ları hedef hücre sayısını bildirir (1x1 = ~56dp,
            // sonrası 70dp'lik hücre formülü); eskiler minWidth/minHeight'a göre.
            val cellsW = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) info.targetCellWidth else 0
            val cellsH = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) info.targetCellHeight else 0
            val defW = when {
                cellsW > 0 -> dp(maxOf(cellsW * 70 - 30, 56))
                info.minWidth > 0 -> minOf(maxOf(info.minWidth, dp(56)), screenW - dp(16))
                else -> screenW - dp(32)
            }
            val defH = when {
                cellsH > 0 -> dp(maxOf(cellsH * 70 - 30, 56))
                else -> maxOf(info.minHeight, dp(56))
            }
            val wPx = if (st.wDp > 0) (st.wDp * density).toInt() else defW
            val hPx = if (st.hDp > 0) (st.hDp * density).toInt() else defH
            host.layoutParams = FrameLayout.LayoutParams(wPx, hPx)
            val wDp = (wPx / density).toInt()
            val hDp = (hPx / density).toInt()
            try {
                host.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
            } catch (e: Exception) {
                // Bazı widget'lar boyut bildirimini desteklemeyebilir
            }
        }
    }

    private fun pickWidget() {
        val providers = appWidgetManager.installedProviders.sortedBy {
            it.loadLabel(packageManager).lowercase(Locale.getDefault())
        }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Yüklü widget bulunamadı", Toast.LENGTH_SHORT).show()
            return
        }
        val density = resources.displayMetrics.density
        val labels = providers.map { p ->
            val appLabel = try {
                packageManager.getApplicationInfo(p.provider.packageName, 0).loadLabel(packageManager).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            "${p.loadLabel(packageManager)} · $appLabel · ${(p.minWidth / density).toInt()}×${(p.minHeight / density).toInt()}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Widget seç")
            .setItems(labels) { _, which -> startWidgetBind(providers[which]) }
            .show()
    }

    private fun startWidgetBind(provider: AppWidgetProviderInfo) {
        val id = appWidgetHost.allocateAppWidgetId()
        val allowed = try {
            appWidgetManager.bindAppWidgetIdIfAllowed(id, provider.provider)
        } catch (e: Exception) {
            false
        }
        if (allowed) {
            onWidgetBound(id, provider)
        } else {
            pendingProvider = provider
            pendingWidgetId = id
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
            }
            try {
                bindWidgetLauncher.launch(intent)
            } catch (e: Exception) {
                appWidgetHost.deleteAppWidgetId(id)
                pendingProvider = null
                pendingWidgetId = -1
                Toast.makeText(this, "Bu widget bağlanamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Widget sisteme bağlandı; ayar (configure) ekranı gerekiyorsa sistem üzerinden başlatılır. */
    private fun onWidgetBound(id: Int, provider: AppWidgetProviderInfo) {
        if (provider.configure != null) {
            pendingConfigureId = id
            try {
                appWidgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                pendingConfigureId = -1
                finalizeWidget(id)
            }
        } else {
            finalizeWidget(id)
        }
    }

    private fun finalizeWidget(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id)
        if (info == null) {
            appWidgetHost.deleteAppWidgetId(id)
            Toast.makeText(this, "Widget yüklenemedi", Toast.LENGTH_SHORT).show()
            return
        }
        val list = LauncherPrefs.getWidgets(this)
        // Yeni widget'lar üst üste binmesin diye hafif kaydırılmış başlar
        val st = WidgetState(id, info.provider.flattenToString(), 0f, list.size * 28f, 0, 0)
        list.add(st)
        LauncherPrefs.saveWidgets(this, list)
        if (!showWidget(st)) {
            removeWidget(id)
            Toast.makeText(this, "Widget yüklenemedi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showWidget(st: WidgetState): Boolean {
        val info = appWidgetManager.getAppWidgetInfo(st.id) ?: return false
        return try {
            widgetBoxes.remove(st.id)?.let { headerLayer.removeView(it) }
            val box = DragLayout(this)
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.topMargin = dp(110)
            box.layoutParams = lp
            val hostView = appWidgetHost.createView(this, st.id, info)
            hostView.setAppWidget(st.id, info)
            hostView.setOnLongClickListener { showWidgetMenu(st.id); true }
            box.setOnLongClickListener { showWidgetMenu(st.id); true }
            box.addView(hostView)
            headerLayer.addView(box)
            widgetBoxes[st.id] = box
            applyWidgetLayouts()
            true
        } catch (e: Exception) {
            widgetBoxes.remove(st.id)?.let { headerLayer.removeView(it) }
            false
        }
    }

    private fun removeWidget(id: Int) {
        try { appWidgetHost.deleteAppWidgetId(id) } catch (e: Exception) {}
        val list = LauncherPrefs.getWidgets(this)
        list.removeAll { it.id == id }
        LauncherPrefs.saveWidgets(this, list)
        widgetBoxes.remove(id)?.let { headerLayer.removeView(it) }
    }

    private fun restoreWidgets() {
        val list = LauncherPrefs.getWidgets(this)
        val kept = list.filter { showWidget(it) }
        if (kept.size != list.size) LauncherPrefs.saveWidgets(this, kept)
    }

    companion object {
        private const val WIDGET_HOST_ID = 1024
        private const val MAX_DOCK = 5
        private const val REQ_CONFIGURE = 7001
    }
}
