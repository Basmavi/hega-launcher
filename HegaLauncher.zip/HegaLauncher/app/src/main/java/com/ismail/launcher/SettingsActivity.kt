package com.ismail.launcher

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private val colors = listOf(
        0xFFFFFFFF.toInt(), // beyaz
        0xFF000000.toInt(), // siyah
        0xFFFFEB3B.toInt(), // sarı
        0xFF00E5FF.toInt(), // camgöbeği
        0xFFFF4081.toInt(), // pembe
        0xFF69F0AE.toInt()  // yeşil
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        setupShapeButtons()
        setupIconSize()
        setupLabelSize()
        setupColorRow()
        setupGridSize()

        findViewById<Button>(R.id.doneBtn).setOnClickListener { finish() }
    }

    private fun setupShapeButtons() {
        val square = findViewById<Button>(R.id.shapeSquare)
        val circle = findViewById<Button>(R.id.shapeCircle)
        val squircle = findViewById<Button>(R.id.shapeSquircle)
        square.setOnClickListener { LauncherPrefs.setIconShape(this, "square") }
        circle.setOnClickListener { LauncherPrefs.setIconShape(this, "circle") }
        squircle.setOnClickListener { LauncherPrefs.setIconShape(this, "squircle") }
    }

    private fun setupIconSize() {
        val label = findViewById<TextView>(R.id.iconSizeLabel)
        val seek = findViewById<SeekBar>(R.id.iconSizeSeek)
        val current = LauncherPrefs.getIconSizeDp(this)
        seek.progress = (current - MIN_ICON_DP).coerceIn(0, seek.max)
        label.text = "Simge boyutu (${current}dp)"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val dp = MIN_ICON_DP + progress
                label.text = "Simge boyutu (${dp}dp)"
                LauncherPrefs.setIconSizeDp(this@SettingsActivity, dp)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupLabelSize() {
        val label = findViewById<TextView>(R.id.labelSizeLabel)
        val seek = findViewById<SeekBar>(R.id.labelSizeSeek)
        val current = LauncherPrefs.getLabelSizeSp(this)
        seek.progress = (current - MIN_LABEL_SP).coerceIn(0, seek.max)
        label.text = "Yazı boyutu (${current}sp)"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val sp = MIN_LABEL_SP + progress
                label.text = "Yazı boyutu (${sp}sp)"
                LauncherPrefs.setLabelSizeSp(this@SettingsActivity, sp)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupColorRow() {
        val row = findViewById<LinearLayout>(R.id.colorRow)
        val dp = (36 * resources.displayMetrics.density).toInt()
        val margin = (6 * resources.displayMetrics.density).toInt()
        colors.forEach { c ->
            val swatch = Button(this)
            swatch.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(2, Color.GRAY)
            }
            val params = LinearLayout.LayoutParams(dp, dp)
            params.setMargins(margin, 0, margin, 0)
            swatch.layoutParams = params
            swatch.text = ""
            swatch.setOnClickListener { LauncherPrefs.setLabelColor(this, c) }
            row.addView(swatch)
        }
        row.gravity = Gravity.CENTER
    }

    private fun setupGridSize() {
        val colLabel = findViewById<TextView>(R.id.columnsLabel)
        val colSeek = findViewById<SeekBar>(R.id.columnsSeek)
        val curCols = LauncherPrefs.getColumns(this)
        colSeek.progress = (curCols - MIN_COLUMNS).coerceIn(0, colSeek.max)
        colLabel.text = "Sütun sayısı ($curCols)"
        colSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = MIN_COLUMNS + progress
                colLabel.text = "Sütun sayısı ($v)"
                LauncherPrefs.setColumns(this@SettingsActivity, v)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val rowLabel = findViewById<TextView>(R.id.rowsLabel)
        val rowSeek = findViewById<SeekBar>(R.id.rowsSeek)
        val curRows = LauncherPrefs.getRows(this)
        rowSeek.progress = (curRows - MIN_ROWS).coerceIn(0, rowSeek.max)
        rowLabel.text = "Satır sayısı (sayfa başına) ($curRows)"
        rowSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = MIN_ROWS + progress
                rowLabel.text = "Satır sayısı (sayfa başına) ($v)"
                LauncherPrefs.setRows(this@SettingsActivity, v)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    companion object {
        private const val MIN_ICON_DP = 40   // seek max=48 -> 40..88
        private const val MIN_LABEL_SP = 10  // seek max=12 -> 10..22
        private const val MIN_COLUMNS = 3    // seek max=3 -> 3..6
        private const val MIN_ROWS = 4       // seek max=3 -> 4..7
    }
}
