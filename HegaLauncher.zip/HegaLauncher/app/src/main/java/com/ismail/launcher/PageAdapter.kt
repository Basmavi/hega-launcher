package com.ismail.launcher

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PageAdapter(
    private var pages: List<List<GridItem>>,
    private val columns: () -> Int,
    private val iconShape: () -> String,
    private val onAppTap: (AppInfo) -> Unit,
    private val onAppLongPress: (AppInfo) -> Unit,
    private val onFolderTap: (GridItem.FolderItem) -> Unit,
    private val onBackgroundLongPress: () -> Unit
) : RecyclerView.Adapter<PageAdapter.PageVH>() {

    inner class PageVH(val grid: RecyclerView) : RecyclerView.ViewHolder(grid)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val grid = LayoutInflater.from(parent.context)
            .inflate(R.layout.page_grid, parent, false) as RecyclerView
        grid.layoutManager = GridLayoutManager(parent.context, columns())
        grid.setOnLongClickListener { onBackgroundLongPress(); true }
        return PageVH(grid)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        (holder.grid.layoutManager as GridLayoutManager).spanCount = columns()
        holder.grid.adapter = AppAdapter(
            items = pages[position],
            iconShape = iconShape,
            onAppTap = onAppTap,
            onAppLongPress = onAppLongPress,
            onFolderTap = onFolderTap
        )
    }

    override fun getItemCount() = pages.size

    fun update(newPages: List<List<GridItem>>) {
        pages = newPages
        notifyDataSetChanged()
    }
}
