# Hega Launcher (v2)

Tamamen yerel çalışan bir Android ana ekran launcher'ı. Bu sürüm önceki kurulumun
üzerine doğrudan kurulabilir (versionCode 2).

## Yeni neler var (v2)
- **Ana ekran boş başlar:** ilk kurulumda hiçbir şey yok, istediğin uygulamayı
  Uygulama Menüsü'nden ekliyorsun.
- **Uygulama Menüsü:** dock'un sağ ucundaki yuvarlak ⠿ butona bas. Orada TÜM
  uygulamalar ve klasörler, yine sağa-sola kaydırmalı sayfalar halinde durur.
  Arama kutusu artık burada.
- **Ana ekrana ekleme:** Uygulama Menüsü'nde bir uygulamaya/klasöre uzun bas →
  "Ana ekrana ekle". Ana ekrandan çıkarmak için ana ekranda uzun basıp
  "Ana ekrandan kaldır"/"çıkar" de.
- **Dock genişledi**, kenarlara daha yakın duruyor.
- **Saat açma/kapama:** Ayarlar'da "Ana ekranda saati göster" anahtarı.
- **Tam ekran düzeltmesi:** alttaki beyaz boşluk sorunu için pencere/tema ayarları
  düzeltildi (kesin çözüldüğünü burada derleyip göremedim, telefonda test etmen gerekiyor).
- **Gerçek uygulama ikonu** (logon, hafif yuvarlatılmış kare).

## Genel özellikler
- Yatay kaydırmalı ana ekran + Uygulama Menüsü, altta sayfa noktaları.
- Dock: en fazla 5 sabit uygulama + Uygulama Menüsü butonu.
- Klasörler: uzun bas → "Klasöre taşı" (Uygulama Menüsü'nde).
- Widget ekleme, duvar kağıdı değiştirme (ana ekranda boş alana uzun bas).
- Ayarlar: simge şekli (Kare/Yuvarlak/Yumuşak kare), simge boyutu, yazı boyutu/
  rengi, sütun/satır sayısı, saat göster/gizle.

## Kurulum (Android Studio)
1. Bu klasörü aç → Android Studio'da **File → Open**.
2. Senkronizasyon Gradle wrapper'ı otomatik ekler, internet ister (ilk sefer).
3. Telefona/emülatöre **Run ▶** ile yükle, ya da GitHub Actions ile APK derleyip
   indir (workflow zaten ayarlı).
4. **Ayarlar → Uygulamalar → Varsayılan uygulamalar → Ana ekran** → Hega Launcher.

## Güncelleme (v1 üzerine v2 kurma)
Bu sürüm sabit bir debug imzalama anahtarı kullanıyor (app/debug.keystore, repoya
dahil) ve versionCode 2. Bu sayede APK'yı eski kurulumun üzerine, silmeden
kurabilirsin — "İmza uyuşmuyor" hatası almazsın.

## Sınırlamalar
- Sayfalar arası sürükle-bırak yok, sıralama eklenme sırasına göre.
- Aynı anda yalnızca bir widget alanı var.
- İkon paketleri desteklenmiyor.

Bunlardan istediğin biri eklensin dersen üzerine koyabiliriz.
