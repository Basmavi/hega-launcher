package com.ismail.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

object IconShaper {

    /**
     * İkonu kare bir alana tam oturacak şekilde maskeler.
     * "circle" = kareye tam oturan gerçek daire.
     * Adaptif ikonlarda sistemin kendi köşeli maskesi devre dışı bırakılır,
     * arka plan/ön plan katmanları doğrudan çizilir.
     */
    fun apply(context: Context, source: Drawable, shape: String, size: Int = 144): Drawable {
        val s = size.coerceAtLeast(48)
        val sf = s.toFloat()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val rect = RectF(0f, 0f, sf, sf)
        when (shape) {
            "circle" -> path.addOval(rect, Path.Direction.CW)
            "squircle" -> path.addRoundRect(rect, sf * 0.3f, sf * 0.3f, Path.Direction.CW)
            else -> path.addRoundRect(rect, sf * 0.14f, sf * 0.14f, Path.Direction.CW)
        }
        canvas.drawPath(path, paint)

        val iconBmp = renderIcon(context, source, s)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(iconBmp, 0f, 0f, paint)

        return BitmapDrawable(context.resources, bmp)
    }

    private fun renderIcon(context: Context, source: Drawable, s: Int): Bitmap {
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val fresh = source.constantState?.newDrawable(context.resources)?.mutate() ?: source

        if (fresh is AdaptiveIconDrawable) {
            // Adaptif ikon: 108 birimlik katman, görünen alan 72 birim.
            val layer = (s * 108f / 72f).toInt()
            val off = (layer - s) / 2
            val bg = fresh.background
            if (bg != null) {
                bg.setBounds(-off, -off, s + off, s + off)
                bg.draw(c)
            }
            val fg = fresh.foreground
            if (fg != null) {
                fg.setBounds(-off, -off, s + off, s + off)
                fg.draw(c)
            }
        } else {
            fresh.setBounds(0, 0, s, s)
            fresh.draw(c)
        }
        return out
    }
}
