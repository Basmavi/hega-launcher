# Hega Launcher

Basit, tamamen yerel çalışan bir Android ana ekran launcher'ı. İnternet gerektirmez,
sadece cihazdaki yüklü uygulamaları okur ve açar.

## İçerik
- Saat ve tarih
- Arama kutusu (yazdıkça uygulamaları ve klasörleri filtreler)
- 4 sütunlu uygulama ızgarası (alfabetik sıralı)
- Uzun basınca uygulamada: "Uygulama bilgisi" / "Klasöre taşı" / "Kaldır" menüsü
- **Klasörler:** bir uygulamayı uzun basıp "Klasöre taşı" ile var olan bir klasöre
  ekleyebilir ya da yeni klasör oluşturabilirsin. Klasöre dokununca içindekiler
  açılır; içeride bir uygulamaya uzun basmak onu klasörden çıkarır.
- **Widget:** boş bir alana (arka plana) uzun bas → "Widget ekle". Yüklü
  widget'lardan birini seçince arama kutusunun altına eklenir. Kaldırmak için
  yine arka plana uzun basıp "Widget'ı kaldır" de.
- **Duvar kağıdı değiştirme:** arka plana uzun bas → "Duvar kağıdını değiştir",
  sistemin kendi duvar kağıdı seçicisi açılır.
- **Simge şekli:** arka plana uzun bas → "Simge şekli" → Kare / Yuvarlak /
  Yumuşak kare. Bütün uygulama ve klasör ikonlarına uygulanır (logonun kendisi
  değişmez, sadece dış hattı/maskesi değişir).
- Arka planda cihazın kendi duvar kağıdı görünür.

## Kurulum (Android Studio)
1. Bu klasörü bilgisayarına indir/kopyala.
2. Android Studio'da **File → Open** ile bu klasörü aç (yeni proje oluşturma, mevcut olanı aç).
3. Gradle wrapper dosyaları bu pakette yok; Android Studio senkronizasyon sırasında
   otomatik olarak ekleyecek/soracaktır. Sorarsa "Yes"/"OK" de.
4. İlk senkronizasyon internet ister (bağımlılıkları indirmek için). Sonrasında
   uygulamanın kendisi tamamen çevrimdışı çalışır.
5. Telefonunu USB ile bağla (geliştirici modu + USB hata ayıklama açık olmalı) veya
   bir emülatör kullan, ardından **Run ▶** ile yükle.

## Varsayılan launcher yapma
Kurulumdan sonra telefonda:
**Ayarlar → Uygulamalar → Varsayılan uygulamalar → Ana ekran uygulaması** yoluna git
ve **Hega Launcher**'ı seç. Vazgeçmek istersen aynı yerden eski launcher'ı geri seçebilirsin.

## Widget hakkında not
Widget ekleme özelliği, uygulaman **henüz varsayılan launcher olarak seçilmemişse**
bir kere ekstra bir izin ekranı açabilir (sistemin kendi onay penceresi). Hega
Launcher'ı varsayılan yaptıktan sonra bu adım otomatik geçilir. Bazı OEM'lerde
(Xiaomi/MIUI, bazı Samsung sürümleri gibi) üçüncü taraf launcher'larda widget
davranışı farklılık gösterebilir; bir widget eklenemezse farklı bir widget ile
dene.

## Sınırlamalar / geliştirilebilecekler
- Klasör/ikon sürükle-bırak yerleşimi yok; klasöre ekleme menüden yapılıyor.
- Aynı anda yalnızca bir widget alanı var (birden fazla widget istenirse eklenebilir).
- İkon paketleri desteklenmiyor, sistemin verdiği ikonlar (şekil maskesiyle) kullanılıyor.
- Bildirim noktaları (badge) yok.

Bunlardan istediğin biri eklensin dersen üzerine koyabiliriz.
