package com.ismail.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.support.v4.media.session.MediaSessionCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat as MediaNotificationCompat
import androidx.media.session.MediaButtonReceiver

class MusicService : Service() {

    interface Listener {
        fun onSongChanged(song: SongInfo?)
        fun onPlaybackStateChanged(playing: Boolean)
    }

    inner class MusicBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    private val binder = MusicBinder()
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var mediaSession: MediaSessionCompat

    var playlist: List<SongInfo> = emptyList()
        private set
    var currentIndex = -1
        private set
    var shuffleOn = false
    var repeatOn = false
    var listener: Listener? = null

    override fun onCreate() {
        super.onCreate()
        mediaSession = MediaSessionCompat(this, "HegaMusicSession")
        mediaSession.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { resume() }
            override fun onPause() { pause() }
            override fun onSkipToNext() { next() }
            override fun onSkipToPrevious() { previous() }
            override fun onSeekTo(pos: Long) { seekTo(pos.toInt()) }
        })
        mediaSession.isActive = true
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == null && getCurrentSong() == null) {
            // startForegroundService() sonrası startForeground() çağrılmazsa sistem uygulamayı kapatır
            startForeground(NOTIF_ID, placeholderNotification())
        }
        when (intent?.action) {
            ACTION_TOGGLE -> togglePlayPause()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> {
                mediaPlayer?.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        MediaButtonReceiver.handleIntent(mediaSession, intent)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        mediaSession.release()
        super.onDestroy()
    }

    fun loadPlaylist(songs: List<SongInfo>) {
        playlist = songs
    }

    fun playAt(index: Int) {
        val song = playlist.getOrNull(index) ?: return
        currentIndex = index
        mediaPlayer?.release()
        mediaPlayer = null
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, song.audioUri)
            mp.setOnPreparedListener {
                it.start()
                listener?.onPlaybackStateChanged(true)
                updateNotification(song, true)
            }
            mp.setOnCompletionListener {
                if (repeatOn) playAt(currentIndex) else next()
            }
            mp.prepareAsync()
            mediaPlayer = mp
        } catch (e: Exception) {
            // oynatılamayan dosya; sessizce geç
        }
        listener?.onSongChanged(song)
        startForeground(NOTIF_ID, buildNotification(song, true))
    }

    fun resume() {
        try { mediaPlayer?.start() } catch (e: Exception) {}
        listener?.onPlaybackStateChanged(true)
        playlist.getOrNull(currentIndex)?.let { updateNotification(it, true) }
    }

    fun pause() {
        try { mediaPlayer?.pause() } catch (e: Exception) {}
        listener?.onPlaybackStateChanged(false)
        playlist.getOrNull(currentIndex)?.let { updateNotification(it, false) }
    }

    fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) pause() else resume()
    }

    fun next() {
        if (playlist.isEmpty()) return
        val nextIndex = if (shuffleOn) {
            if (playlist.size == 1) 0 else {
                var r: Int
                do { r = (0 until playlist.size).random() } while (r == currentIndex)
                r
            }
        } else {
            if (currentIndex + 1 < playlist.size) currentIndex + 1 else 0
        }
        playAt(nextIndex)
    }

    fun previous() {
        if (playlist.isEmpty()) return
        val prevIndex = if (currentIndex - 1 >= 0) currentIndex - 1 else playlist.size - 1
        playAt(prevIndex)
    }

    fun seekTo(ms: Int) {
        try { mediaPlayer?.seekTo(ms) } catch (e: Exception) {}
    }

    fun isPlaying(): Boolean = try { mediaPlayer?.isPlaying == true } catch (e: Exception) { false }
    fun getDuration(): Int = try { mediaPlayer?.duration ?: 0 } catch (e: Exception) { 0 }
    fun getCurrentPosition(): Int = try { mediaPlayer?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun getCurrentSong(): SongInfo? = playlist.getOrNull(currentIndex)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Hega Music", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(song: SongInfo, playing: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(NOTIF_ID, buildNotification(song, playing))
    }

    private fun buildNotification(song: SongInfo, playing: Boolean): Notification {
        val toggleIntent = PendingIntent.getService(
            this, 1, Intent(this, MusicService::class.java).setAction(ACTION_TOGGLE), pendingFlags()
        )
        val nextIntent = PendingIntent.getService(
            this, 2, Intent(this, MusicService::class.java).setAction(ACTION_NEXT), pendingFlags()
        )
        val prevIntent = PendingIntent.getService(
            this, 3, Intent(this, MusicService::class.java).setAction(ACTION_PREV), pendingFlags()
        )
        val contentIntent = PendingIntent.getActivity(
            this, 4, Intent(this, MusicActivity::class.java), pendingFlags()
        )

        val art = try { MusicScanner.loadArt(this, song, 256) } catch (e: Exception) { null }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(song.title)
            .setContentText(song.artist)
            .setLargeIcon(art)
            .setContentIntent(contentIntent)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_previous, "Önceki", prevIntent)
            .addAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Duraklat" else "Oynat",
                toggleIntent
            )
            .addAction(android.R.drawable.ic_media_next, "Sonraki", nextIntent)
            .setStyle(
                MediaNotificationCompat.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    private fun placeholderNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle("Hega Music")
            .setContentText("Hazırlanıyor…")
            .setOnlyAlertOnce(true)
            .build()

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

    companion object {
        const val CHANNEL_ID = "hega_music"
        const val NOTIF_ID = 42
        const val ACTION_TOGGLE = "com.ismail.launcher.music.TOGGLE"
        const val ACTION_NEXT = "com.ismail.launcher.music.NEXT"
        const val ACTION_PREV = "com.ismail.launcher.music.PREV"
        const val ACTION_STOP = "com.ismail.launcher.music.STOP"
    }
}
