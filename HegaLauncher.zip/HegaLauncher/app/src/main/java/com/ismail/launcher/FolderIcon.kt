package com.ismail.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

object FolderIcon {
    fun build(context: Context, icons: List<Drawable>, size: Int = 144): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x552B2B2B.toInt() }
        canvas.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.28f, size * 0.28f, bg)

        val cell = size / 2
        val pad = (cell * 0.14f).toInt()
        icons.take(4).forEachIndexed { i, d ->
            val col = i % 2
            val row = i / 2
            val fresh = d.constantState?.newDrawable(context.resources)?.mutate() ?: d
            fresh.setBounds(col * cell + pad, row * cell + pad, (col + 1) * cell - pad, (row + 1) * cell - pad)
            fresh.draw(canvas)
        }
        return BitmapDrawable(context.resources, bmp)
    }
}
