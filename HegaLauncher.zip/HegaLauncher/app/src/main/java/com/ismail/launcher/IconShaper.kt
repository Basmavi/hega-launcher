package com.ismail.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

object IconShaper {
    fun apply(context: Context, source: Drawable, shape: String, size: Int = 144): Drawable {
        if (shape == "square") return source

        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val path = Path()
        when (shape) {
            "circle" -> path.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
            "squircle" -> path.addRoundRect(
                RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.3f, size * 0.3f, Path.Direction.CW
            )
            else -> path.addRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), Path.Direction.CW)
        }
        canvas.clipPath(path)

        val fresh = source.constantState?.newDrawable(context.resources)?.mutate() ?: source
        fresh.setBounds(0, 0, size, size)
        fresh.draw(canvas)
        return BitmapDrawable(context.resources, bmp)
    }
}
