package com.ismail.launcher

sealed class HomeEntry {
    data class AppEntry(val ref: AppRef) : HomeEntry()
    data class FolderEntry(val folderName: String) : HomeEntry()
}
